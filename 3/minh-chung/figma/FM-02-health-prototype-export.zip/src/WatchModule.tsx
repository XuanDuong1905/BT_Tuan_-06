import { useEffect, useState } from 'react'
import { Icon, type IconName } from './ui'
import { initialActivities, type Activity } from './activityData'

export default function WatchModule({ onSync }: { onSync: (activity: Activity) => void }) {
  const [watchState, setWatchState] = useState('tracking')
  const [watchType, setWatchType] = useState<IconName>('run')
  const [seconds, setSeconds] = useState(1938)
  useEffect(() => {
    if (watchState !== 'tracking') return
    const timer = setInterval(() => setSeconds(s => s + 1), 1000)
    return () => clearInterval(timer)
  }, [watchState])
  useEffect(() => {
    if (watchState !== 'syncing') return
    const timer = setTimeout(() => {
      setWatchState('synced')
      onSync({ ...initialActivities[0], name: 'Buổi tập vừa hoàn thành', type: ({ run: 'Chạy bộ', walk: 'Đi bộ', bike: 'Đạp xe', swim: 'Bơi lội' } as Record<string, string>)[watchType], icon: watchType, date: 'Hôm nay, vừa xong' })
    }, 2200)
    return () => clearTimeout(timer)
  }, [watchState, watchType, onSync])
  return <section className="watch-panel"><div className="section-bar"><h2>Đồng hồ của bạn</h2><span className="connected"><i /> Trực tuyến</span></div><p>Theo dõi từng chuyển động, ngay trên cổ tay.</p><div className="watch-stage"><div className="watch-strap top" /><div className="watch-body"><div className="watch-screen"><div className="watch-status"><span>09:41</span><span><Icon name="bluetooth" size={12} /> ▰</span></div>{watchState === 'tracking' ? <><div className="watch-activity"><Icon name={watchType} size={24} /><span>{({run:'Chạy bộ',walk:'Đi bộ',bike:'Đạp xe',swim:'Bơi lội'} as Record<string,string>)[watchType]}</span></div><div className="auto-detect"><i /> Tự động nhận diện</div><div className="watch-timer">{Math.floor(seconds / 60).toString().padStart(2,'0')}<span>:</span>{(seconds % 60).toString().padStart(2,'0')}</div><div className="watch-metrics"><div><strong>5,24</strong><span>km</span></div><div><strong>9,7</strong><span>km/h TB</span></div></div><div className="watch-heart"><Icon name="heart" size={15} /><strong>142</strong><span>bpm</span><svg viewBox="0 0 65 20"><path d="M0 10h15l4-5 5 13 7-17 7 12 4-3h23" /></svg></div><button className="watch-end" onClick={() => setWatchState('pending')}><span /> Kết thúc</button></> : <div className="watch-finished"><span className="finish-check"><Icon name={watchState === 'synced' ? 'check' : watchState === 'syncing' ? 'bluetooth' : 'check'} size={30} /></span><strong>{watchState === 'synced' ? 'Đã đồng bộ!' : watchState === 'syncing' ? 'Đang đồng bộ...' : 'Đã lưu hoạt động'}</strong><p>{watchState === 'pending' ? 'Dữ liệu đã lưu trên đồng hồ. Chờ ghép nối Bluetooth.' : watchState === 'syncing' ? 'Đang chuyển dữ liệu đến điện thoại' : 'Hoạt động đã có trên điện thoại của bạn.'}</p><span className="finished-distance">5,24 <small>km</small></span><button className="watch-end" disabled={watchState === 'syncing'} onClick={() => { if(watchState === 'pending') setWatchState('syncing'); else {setWatchState('tracking'); setSeconds(0)} }}>{watchState === 'synced' ? 'Buổi tập mới' : watchState === 'syncing' ? 'Đang gửi...' : 'Ghép nối & đồng bộ'}</button></div>}</div></div><div className="watch-crown" /><div className="watch-strap bottom" /></div><div className="watch-type-picker">{(['walk','run','bike','swim'] as IconName[]).map(t => <button key={t} disabled={watchState !== 'tracking'} className={watchType === t ? 'selected' : ''} aria-label={`Mô phỏng ${t}`} onClick={() => setWatchType(t)}><Icon name={t} size={18} /></button>)}</div><div className="sync-note"><Icon name="bluetooth" size={17} /><span>{watchState === 'synced' ? 'Đồng bộ vừa xong' : watchState === 'pending' ? 'Chờ ghép nối với điện thoại' : watchState === 'syncing' ? 'Đang đồng bộ dữ liệu...' : 'Tự động đồng bộ qua Bluetooth'}</span><span className="sync-dot" /></div></section>
}
