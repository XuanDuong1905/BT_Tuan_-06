import { useLayoutEffect, useRef, type ReactNode } from 'react'

// Keep each tab mounted and restore its own scroll offset after it becomes visible.
export default function RetainedPanel({ active, children, id, labelledBy, className = '' }: {
  active: boolean; children: ReactNode; id: string; labelledBy?: string; className?: string
}) {
  const element = useRef<HTMLElement>(null)
  const scroll = useRef(0)
  useLayoutEffect(() => {
    if (active && element.current) element.current.scrollTop = scroll.current
  }, [active])
  return <section id={id} ref={element} hidden={!active} role={labelledBy ? 'tabpanel' : undefined}
    aria-labelledby={labelledBy} className={`retained-panel ${className}`}
    onScroll={event => { if (active) scroll.current = event.currentTarget.scrollTop }}>
    {children}
  </section>
}
