import { useEffect, useRef, useState } from "react"
import { Icon, type IconName } from "./ui"
import { ShareButton, ShareHeading, ShareInput } from "./ShareControls"
import {
  buildShareContent,
  renderShareSvg,
  shareOptions,
  sharingPeriod,
  workoutsInPeriod,
  type PeriodKind,
  type ShareKey,
  type ShareWorkout,
} from "./workoutSharing"
import "./sharing.css"

type Props = {
  workouts: ShareWorkout[]
  workout?: ShareWorkout
  initialPeriod: PeriodKind
  initialValue?: string
  onClose: () => void
}

const optionIcons: Partial<Record<ShareKey, IconName>> = {
  name: "activity",
  type: "run",
  date: "calendar",
  time: "clock",
  count: "grid",
  distance: "distance",
  duration: "clock",
  speed: "activity",
  heart: "heart",
  calories: "activity",
  elevation: "target",
  map: "distance",
  speedChart: "activity",
  heartChart: "heart",
  elevationChart: "target",
  splits: "grid",
}

const optionGroups: {
  label: string
  keys: ShareKey[]
}[] = [
  { label: "Thông tin hoạt động", keys: ["name", "type", "date", "time"] },
  {
    label: "Chỉ số của bạn",
    keys: [
      "distance",
      "speed",
      "duration",
      "count",
      "calories",
      "heart",
      "elevation",
    ],
  },
  {
    label: "Bản đồ & phân tích",
    keys: ["map", "speedChart", "heartChart", "elevationChart", "splits"],
  },
]

function DestinationIcon({ name }: { name: string }) {
  if (name === "Ứng dụng khác") return <Icon name="share" size={22} />
  return (
    <svg
      width="22"
      height="22"
      viewBox="0 0 24 24"
      fill="none"
      aria-hidden="true"
    >
      {name === "Facebook" ? (
        <path
          d="M14 22v-9h3l.5-4H14V7c0-1 .3-2 2-2h2V1.5C17.5 1.2 16 1 15 1c-3 0-5 2-5 5v3H7v4h3v9"
          fill="currentColor"
        />
      ) : (
        <g stroke="currentColor" strokeWidth="1.7">
          <rect x="3" y="3" width="18" height="18" rx="5" />
          <circle cx="12" cy="12" r="4" />
          <circle cx="17.5" cy="6.5" r=".8" fill="currentColor" stroke="none" />
        </g>
      )}
    </svg>
  )
}

export default function ShareCustomizer({
  workouts,
  workout,
  initialPeriod,
  initialValue,
  onClose,
}: Props) {
  const single = !!workout
  const options = shareOptions.filter((option) =>
    single ? !option.summaryOnly : !option.singleOnly,
  )
  const [selected, setSelected] = useState<Set<ShareKey>>(
    () =>
      new Set(
        options
          .filter((option) =>
            [
              "name",
              "type",
              "date",
              "time",
              "count",
              "distance",
              "speed",
              "duration",
              "map",
            ].includes(option.key),
          )
          .map((option) => option.key),
      ),
  )
  const [kind, setKind] = useState<PeriodKind>(initialPeriod)
  const [dates, setDates] = useState({
    week:
      initialPeriod === "week" && initialValue ? initialValue : "2025-05-24",
    month: initialPeriod === "month" && initialValue ? initialValue : "2025-05",
    year: initialPeriod === "year" && initialValue ? initialValue : "2025",
  })
  const [layout, setLayout] = useState<"square" | "story">("square")
  const [platform, setPlatform] = useState("Facebook")
  const [confirmation, setConfirmation] = useState("")
  const [saving, setSaving] = useState(false)
  const dialog = useRef<HTMLElement>(null)

  useEffect(() => {
    const previous = document.activeElement as HTMLElement | null
    const previousOverflow = document.body.style.overflow
    document.body.style.overflow = "hidden"
    dialog.current?.focus()
    return () => {
      document.body.style.overflow = previousOverflow
      previous?.focus()
    }
  }, [])

  // A confirmation always refers to the exact selection currently shown.
  useEffect(
    () => setConfirmation(""),
    [selected, kind, dates, layout, platform],
  )

  const period = sharingPeriod(kind, dates[kind])
  const included = single
    ? [workout]
    : workoutsInPeriod(workouts, kind, dates[kind])
  const content = buildShareContent(
    included,
    selected,
    single,
    period?.rangeLabel ?? "",
    kind,
  )
  const svg = renderShareSvg(content, layout)
  const imageUrl = `data:image/svg+xml;charset=utf-8,${encodeURIComponent(svg)}`
  const disabled =
    selected.size === 0 || included.length === 0 || (!single && !period)

  const changeSelection = (key: ShareKey) => {
    setSelected((current) => {
      const next = new Set(current)
      if (next.has(key)) next.delete(key)
      else next.add(key)
      return next
    })
  }
  const saveImage = async () => {
    if (disabled || saving) return
    setSaving(true)
    try {
      const image = new Image()
      image.src = imageUrl
      await image.decode()
      const canvas = document.createElement("canvas")
      canvas.width = 1080
      canvas.height = layout === "square" ? 1080 : 1920
      const context = canvas.getContext("2d")
      if (!context) throw new Error("canvas")
      context.drawImage(image, 0, 0, canvas.width, canvas.height)
      const blob = await new Promise<Blob>((resolve, reject) =>
        canvas.toBlob(
          (result) => (result ? resolve(result) : reject(new Error("png"))),
          "image/png",
        ),
      )
      const url = URL.createObjectURL(blob)
      const link = document.createElement("a")
      link.href = url
      link.download = `nhip-${
        single
          ? "buoi-tap"
          : kind === "week"
            ? "tuan"
            : kind === "month"
              ? "thang"
              : "nam"
      }-${layout === "square" ? "bai-dang" : "tin"}.png`
      link.click()
      setTimeout(() => URL.revokeObjectURL(url), 1000)
      setConfirmation(
        "Ảnh PNG đã được tạo và yêu cầu tải xuống. Không có bài đăng nào được gửi lên mạng xã hội.",
      )
    } catch {
      setConfirmation(
        "Chưa lưu được ảnh. Vui lòng thử lại; không có nội dung nào được đăng lên mạng xã hội.",
      )
    } finally {
      setSaving(false)
    }
  }

  return (
    <div className="modal-backdrop share-backdrop" onClick={onClose}>
      <section
        className="share-dialog"
        ref={dialog}
        role="dialog"
        aria-modal="true"
        aria-labelledby="share-title"
        tabIndex={-1}
        onClick={(event) => event.stopPropagation()}
        onKeyDown={(event) => {
          if (event.key === "Escape") {
            event.stopPropagation()
            onClose()
          }
          if (event.key !== "Tab") return
          const focusable = [
            ...(dialog.current?.querySelectorAll<HTMLElement>(
              'button:not(:disabled), input, summary, [tabindex="0"]',
            ) ?? []),
          ]
          const first = focusable[0],
            last = focusable[focusable.length - 1]
          if (
            event.shiftKey &&
            (document.activeElement === first ||
              document.activeElement === dialog.current)
          ) {
            event.preventDefault()
            last?.focus()
          } else if (
            !event.shiftKey &&
            (document.activeElement === last ||
              document.activeElement === dialog.current)
          ) {
            event.preventDefault()
            first?.focus()
          }
        }}
      >
        <div className="share-heading">
          <ShareButton
            className="share-back-button"
            onClick={onClose}
            aria-label={
              single ? "Quay lại chi tiết hoạt động" : "Quay lại thống kê"
            }
          >
            <span className="share-back-chevron">
              <Icon name="chevron" size={18} />
            </span>
            Quay lại
          </ShareButton>
          <ShareHeading level={2} id="share-title">
            Chia sẻ thành tích
          </ShareHeading>
          <span className="share-brand" aria-hidden="true">
            nhịp.
          </span>
        </div>

        <div className="share-scroll-body">
          <section
            className="share-preview-section"
            aria-labelledby="share-preview-title"
          >
            <div className="share-preview-heading">
              <div>
                <span className="share-kicker">THEO NHỊP CỦA BẠN</span>
                <ShareHeading id="share-preview-title">
                  {single
                    ? "Một buổi tập, một dấu ấn."
                    : "Nhìn lại hành trình của bạn."}
                </ShareHeading>
              </div>
              <span className="share-live">
                <i /> Trực tiếp
              </span>
            </div>
            <div className="share-preview-stage">
              <div className={`share-image-frame ${layout}`}>
                {disabled ? (
                  <div className="share-empty-preview">
                    <Icon name="activity" size={32} />
                    <strong>
                      {selected.size === 0
                        ? "Bạn muốn kể điều gì?"
                        : "Chưa có buổi tập"}
                    </strong>
                    <p>
                      {selected.size === 0
                        ? "Chọn nội dung bên dưới để tạo ảnh của riêng bạn."
                        : "Hãy chọn giai đoạn có dữ liệu để tạo ảnh tổng kết."}
                    </p>
                  </div>
                ) : (
                  <img
                    src={imageUrl}
                    alt={`Xem trước ảnh chia sẻ. ${content.caption}`}
                  />
                )}
              </div>
              <span className="share-preview-format">
                <Icon name="grid" size={12} />
                {layout === "square"
                  ? "Bài đăng · 1:1 · 1080 × 1080"
                  : "Tin · 9:16 · 1080 × 1920"}
              </span>
            </div>
            <p className="share-preview-hint">
              <Icon name="check" size={13} /> Chỉ những gì bạn chọn mới xuất
              hiện trong ảnh.
            </p>
          </section>

          <section
            className="share-setting-section"
            aria-labelledby="share-content-title"
          >
            <div className="share-section-heading">
              <div>
                <span className="share-step">01</span>
                <ShareHeading id="share-content-title">
                  Chọn nội dung
                </ShareHeading>
              </div>
              <ShareButton
                className="share-text-button"
                onClick={() =>
                  setSelected(
                    selected.size
                      ? new Set()
                      : new Set(options.map((option) => option.key)),
                  )
                }
              >
                {selected.size ? "Bỏ chọn tất cả" : "Chọn tất cả"}
              </ShareButton>
            </div>
            <p className="share-section-description">
              {single
                ? "Chạm để giữ lại điều bạn muốn kể. Ảnh cập nhật ngay."
                : "Chọn giai đoạn và những chỉ số bạn muốn chia sẻ."}
            </p>

            {!single && (
              <div className="share-period-settings">
                <span className="share-field-label">Giai đoạn tổng kết</span>
                <div className="share-period-row">
                  <div
                    className="segmented share-period-tabs"
                    aria-label="Giai đoạn tổng kết"
                  >
                    {([
                      ["week", "Tuần"],
                      ["month", "Tháng"],
                      ["year", "Năm"],
                    ] as const).map(([key, label]) => (
                      <ShareButton
                        key={key}
                        aria-pressed={kind === key}
                        className={kind === key ? "selected" : ""}
                        onClick={() => setKind(key)}
                      >
                        {label}
                      </ShareButton>
                    ))}
                  </div>
                  <ShareInput
                    aria-label={
                      kind === "week"
                        ? "Tuần chứa ngày"
                        : kind === "month"
                          ? "Chọn tháng"
                          : "Chọn năm"
                    }
                    type={
                      kind === "week"
                        ? "date"
                        : kind === "month"
                          ? "month"
                          : "number"
                    }
                    min={kind === "year" ? 2000 : undefined}
                    max={kind === "year" ? 2100 : undefined}
                    value={dates[kind]}
                    onChange={(event) =>
                      setDates((current) => ({
                        ...current,
                        [kind]: event.target.value,
                      }))
                    }
                  />
                </div>
                <p className="share-data-hint">
                  Dữ liệu mẫu: 21–24/05/2025 · Chỉ tính các buổi trong giai đoạn
                  đã chọn.
                </p>
              </div>
            )}
            <div className="share-option-groups">
              {optionGroups.map((group) => {
                const items = group.keys.flatMap((key) =>
                  options.filter((option) => option.key === key),
                )
                if (!items.length) return null
                return (
                  <div
                    className="share-option-group"
                    key={group.label}
                    role="group"
                    aria-label={group.label}
                  >
                    <span className="share-field-label">{group.label}</span>
                    <div className="share-options">
                      {items.map((option) => (
                        <ShareButton
                          key={option.key}
                          className={`share-option ${
                            selected.has(option.key) ? "selected" : ""
                          }`}
                          aria-pressed={selected.has(option.key)}
                          onClick={() => changeSelection(option.key)}
                          data-share-key={option.key}
                        >
                          {optionIcons[option.key] && (
                            <Icon name={optionIcons[option.key]!} size={15} />
                          )}
                          <span>
                            {option.key === "date"
                              ? single
                                ? "Ngày tập"
                                : "Khoảng thời gian"
                              : option.label}
                          </span>
                          <span
                            className="share-option-check"
                            aria-hidden="true"
                          >
                            <Icon
                              name={selected.has(option.key) ? "check" : "plus"}
                              size={12}
                            />
                          </span>
                        </ShareButton>
                      ))}
                    </div>
                  </div>
                )
              })}
            </div>
          </section>

          <section
            className="share-setting-section"
            aria-labelledby="share-layout-title"
          >
            <div className="share-section-heading">
              <div>
                <span className="share-step">02</span>
                <ShareHeading id="share-layout-title">Chọn bố cục</ShareHeading>
              </div>
              <span className="share-section-meta">
                Cùng nội dung, khác góc nhìn
              </span>
            </div>
            <div className="share-layouts">
              {([
                ["square", "Bài đăng", "1:1", "1080 × 1080"],
                ["story", "Tin", "9:16", "1080 × 1920"],
              ] as const).map(([key, label, ratio, size]) => (
                <ShareButton
                  key={key}
                  aria-pressed={layout === key}
                  className={layout === key ? "selected" : ""}
                  onClick={() => setLayout(key)}
                >
                  <span
                    className={`share-layout-mini ${key}`}
                    aria-hidden="true"
                  >
                    {!disabled && (
                      <img
                        src={`data:image/svg+xml;charset=utf-8,${encodeURIComponent(renderShareSvg(content, key))}`}
                        alt=""
                      />
                    )}
                  </span>
                  <span className="share-layout-info">
                    <strong>{label}</strong>
                    <small>
                      {ratio} · {size}
                    </small>
                  </span>
                  <span className="share-layout-radio" aria-hidden="true">
                    {layout === key && <i />}
                  </span>
                </ShareButton>
              ))}
            </div>
            {(content.charts.length > 0 ||
              content.splits.length > 0 ||
              (content.map && content.fields.length > 8)) &&
              layout === "square" && (
                <p className="share-data-hint">
                  Nhiều chi tiết? Chọn bố cục Tin để biểu đồ và từng km dễ đọc
                  hơn.
                </p>
              )}
          </section>

          <section
            className="share-setting-section share-destination-section"
            aria-labelledby="share-destination-title"
          >
            <div className="share-section-heading">
              <div>
                <span className="share-step">03</span>
                <ShareHeading id="share-destination-title">
                  Sẵn sàng chia sẻ
                </ShareHeading>
              </div>
              <span className="share-simulation-badge">Mô phỏng</span>
            </div>
            <div className="share-platforms" aria-label="Chọn nơi chia sẻ">
              {["Facebook", "Instagram", "Ứng dụng khác"].map((item) => (
                <ShareButton
                  key={item}
                  className={`share-destination ${
                    platform === item ? "selected" : ""
                  }`}
                  aria-pressed={platform === item}
                  onClick={() => setPlatform(item)}
                >
                  <span className="share-destination-icon">
                    <DestinationIcon name={item} />
                  </span>
                  <span>{item}</span>
                  {platform === item && (
                    <span className="share-destination-check">
                      <Icon name="check" size={10} />
                    </span>
                  )}
                </ShareButton>
              ))}
              <ShareButton
                className="share-destination"
                disabled={disabled || saving}
                onClick={saveImage}
              >
                <span className="share-destination-icon">
                  <svg
                    width="22"
                    height="22"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="1.7"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    aria-hidden="true"
                  >
                    <path d="M12 3v12m-4-4 4 4 4-4M4 16v5h16v-5" />
                  </svg>
                </span>
                <span>{saving ? "Đang lưu…" : "Lưu ảnh"}</span>
              </ShareButton>
            </div>
            <details className="share-caption-details">
              <summary>
                Xem chú thích đi kèm <Icon name="chevron" size={13} />
              </summary>
              <div className="share-caption">
                {disabled
                  ? "Chọn nội dung và giai đoạn có dữ liệu để tạo chú thích."
                  : content.caption}
              </div>
            </details>
            <p className="share-prototype-note">
              Chia sẻ trên nền tảng chỉ là mô phỏng. Không đăng bài thật hoặc
              gửi dữ liệu đến ứng dụng khác.
            </p>
          </section>

          {disabled && (
            <p className="share-validation" role="status">
              {selected.size === 0
                ? "Hãy chọn ít nhất một nội dung để chia sẻ hoặc lưu ảnh."
                : !single && !period
                  ? "Vui lòng chọn giai đoạn hợp lệ."
                  : "Không có buổi tập trong giai đoạn này. Hãy chọn giai đoạn khác."}
            </p>
          )}
        </div>

        <div className="share-actions">
          {confirmation && (
            <div className="share-confirmation" role="status">
              <Icon name="check" size={18} />
              <div>
                <strong>
                  {confirmation.startsWith("Mô phỏng")
                    ? "Chia sẻ mô phỏng"
                    : "Thông báo lưu ảnh"}
                </strong>
                <p>{confirmation}</p>
              </div>
            </div>
          )}
          <ShareButton
            className="primary-button share-main-action"
            disabled={disabled || saving}
            onClick={() => {
              setConfirmation(
                `Mô phỏng chia sẻ tới ${platform}: ảnh và chú thích chỉ chứa nội dung đã chọn. Chưa đăng hoặc gửi nội dung đến nền tảng nào.`,
              )
            }}
          >
            <Icon name="share" size={17} />
            {platform === "Ứng dụng khác"
              ? "Mô phỏng chia sẻ qua ứng dụng khác"
              : `Mô phỏng chia sẻ qua ${platform}`}
            <Icon name="arrow" size={17} />
          </ShareButton>
          <p>
            {selected.size} mục đã chọn <span>·</span> Chia sẻ mô phỏng, không
            đăng bài thật
          </p>
        </div>
      </section>
    </div>
  )
}
