import type { ReactNode } from 'react'

export default function TabNavigation({ options, value, onChange, prefix, label, className = '' }: {
  options: { key: string; label: string; icon?: ReactNode }[]
  value: string; onChange: (key: string) => void; prefix: string; label: string; className?: string
}) {
  return <div role="tablist" aria-label={label} className={className} onKeyDown={event => {
    if (!['ArrowLeft', 'ArrowRight', 'Home', 'End'].includes(event.key)) return
    event.preventDefault()
    const index = options.findIndex(option => option.key === value)
    const nextIndex = event.key === 'Home' ? 0 : event.key === 'End' ? options.length - 1 : (index + (event.key === 'ArrowRight' ? 1 : -1) + options.length) % options.length
    const next = options[nextIndex].key
    onChange(next)
    event.currentTarget.querySelector<HTMLButtonElement>(`[data-tab="${next}"]`)?.focus()
  }}>
    {options.map(option => <button key={option.key} id={`${prefix}-tab-${option.key}`} data-tab={option.key} role="tab"
      aria-selected={value === option.key} aria-controls={`${prefix}-panel-${option.key}`}
      tabIndex={value === option.key ? 0 : -1} className={value === option.key ? 'active' : ''}
      onClick={() => onChange(option.key)}>{option.icon}<span>{option.label}</span></button>)}
  </div>
}
