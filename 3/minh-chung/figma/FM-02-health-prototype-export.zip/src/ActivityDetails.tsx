import { useState } from 'react'
import { Icon, RouteMap } from './ui'
import type { Activity } from './activityData'
import WorkoutInsights, { InsightSummary } from './WorkoutInsights'
import WorkoutPerformance, { KilometerBreakdown, PerformanceSummary } from './WorkoutPerformance'
import RetainedPanel from './RetainedPanel'
import TabNavigation from './TabNavigation'

const tabs = [{ key: 'overview', label: 'Tổng quan' }, { key: 'charts', label: 'Biểu đồ' }, { key: 'splits', label: 'Từng km' }]
export default function ActivityDetails({ workout, active, onBack, onShare }: {
  workout: Activity; active: boolean; onBack: () => void; onShare: () => void
}) {
  const [tab, setTab] = useState('overview')
  const [metric, setMetric] = useState('speed')
  return <section className="activity-details" aria-label="Chi tiết hoạt động">
    <div className="detail-toolbar"><button className="back-button" onClick={onBack}><span className="back-icon"><Icon name="arrow" size={17} /></span>Quay lại</button><button className="primary-button" onClick={onShare}><Icon name="share" size={16} />Chia sẻ</button></div>
    <div className="detail-title"><span className="eyebrow">{workout.type.toUpperCase()} · {workout.date} · {workout.time}</span><h2>{workout.name}</h2></div>
    <TabNavigation options={tabs} value={tab} onChange={setTab} prefix="detail" label="Chi tiết buổi tập" className="secondary-tabs" />
    <div className="detail-tab-panels">
      <RetainedPanel active={active && tab === 'overview'} id="detail-panel-overview" labelledBy="detail-tab-overview">
        <RouteMap />
        <div className="detail-stats workout-basics">{[[workout.distance, 'Quãng đường (km)'], [workout.duration, 'Tổng thời gian']].map(([value, label]) => <div key={label}><strong>{value}</strong><span>{label}</span></div>)}</div>
        <PerformanceSummary workout={workout} />
        <InsightSummary workout={workout} />
        <p className="panel-footnote">Chuyển sang Biểu đồ để xem thay đổi theo thời gian, hoặc Từng km để so sánh các đoạn.</p>
      </RetainedPanel>
      <RetainedPanel active={active && tab === 'charts'} id="detail-panel-charts" labelledBy="detail-tab-charts">
        <label className="chart-metric-picker">Chỉ số biểu đồ<select value={metric} onChange={event => setMetric(event.target.value)}>
          <option value="speed">Tốc độ</option><option value="heart">Nhịp tim</option><option value="calories">Calo tiêu thụ</option><option value="elevation">Độ cao</option>
        </select></label>
        <div hidden={metric !== 'speed' && metric !== 'heart'}><WorkoutPerformance workout={workout} metricOverride={metric === 'heart' ? 'heartRate' : 'speed'} /></div>
        <div hidden={metric !== 'calories' && metric !== 'elevation'}><WorkoutInsights workout={workout} chartOnly metricOverride={metric === 'elevation' ? 'elevation' : 'calories'} /></div>
      </RetainedPanel>
      <RetainedPanel active={active && tab === 'splits'} id="detail-panel-splits" labelledBy="detail-tab-splits"><KilometerBreakdown workout={workout} /></RetainedPanel>
    </div>
  </section>
}
