import { useState } from 'react'
import { Icon, type IconName } from './ui'
import { shareTotals, sharingPeriod, workoutsInPeriod, formatShareNumber as number, type PeriodKind, type ShareWorkout } from './workoutSharing'

const periodOptions = [{ key: 'week', label: 'Tuần' }, { key: 'month', label: 'Tháng' }, { key: 'year', label: 'Năm' }] as const
export default function Statistics({ workouts, onShare }: { workouts: ShareWorkout[]; onShare: (kind: PeriodKind, value: string) => void }) {
  const [kind, setKind] = useState<PeriodKind>('week')
  const [dates, setDates] = useState({ week: '2025-05-24', month: '2025-05', year: '2025' })
  const [selectedBar, setSelectedBar] = useState<number | null>(null)
  const period = sharingPeriod(kind, dates[kind])
  const included = workoutsInPeriod(workouts, kind, dates[kind])
  const totals = shareTotals(included)
  const buckets: { label: string; value: number }[] = []
  if (period) {
    const start = new Date(`${period.start}T00:00:00Z`)
    const end = new Date(`${period.end}T00:00:00Z`)
    const count = kind === 'week' ? 7 : kind === 'year' ? 12 : Math.ceil((end.getTime() - start.getTime()) / 86400000 / 7)
    for (let i = 0; i < count; i++) {
      const from = new Date(start), to = new Date(start)
      if (kind === 'year') { from.setUTCMonth(i); to.setUTCMonth(i + 1) }
      else { const step = kind === 'week' ? 1 : 7; from.setUTCDate(start.getUTCDate() + i * step); to.setUTCDate(start.getUTCDate() + (i + 1) * step) }
      const rows = included.filter(w => w.isoDate >= from.toISOString().slice(0, 10) && w.isoDate < to.toISOString().slice(0, 10))
      buckets.push({ label: kind === 'week' ? ['T2', 'T3', 'T4', 'T5', 'T6', 'T7', 'CN'][i] : kind === 'year' ? `Th ${i + 1}` : `${i * 7 + 1}–${Math.min((i + 1) * 7, new Date(end.getTime() - 86400000).getUTCDate())}`, value: shareTotals(rows).distance })
    }
  }
  const maximum = Math.max(5, Math.ceil(Math.max(0, ...buckets.map(bucket => bucket.value)) / 5) * 5)
  const cards: { label: string; value: string; unit: string; icon: IconName; color: string }[] = [
    { label: 'Tổng hoạt động', value: `${totals.count}`, unit: 'buổi', icon: 'activity', color: 'green' },
    { label: 'Quãng đường', value: number(totals.distance, 2), unit: 'km', icon: 'distance', color: 'blue' },
    { label: 'Thời gian', value: number(totals.duration / 60, 1), unit: 'phút', icon: 'clock', color: 'orange' },
    { label: 'Calo tiêu thụ', value: number(totals.calories, 0), unit: 'kcal', icon: 'activity', color: 'orange' },
    { label: 'Tốc độ trung bình', value: number(totals.speed), unit: 'km/h', icon: 'distance', color: 'green' },
    { label: 'Nhịp tim trung bình', value: number(totals.heart, 0), unit: 'bpm', icon: 'heart', color: 'purple' },
  ]
  return <div className="statistics-screen">
    <div className="section-bar"><div><h2>Nhịp vận động của bạn</h2><p>Tổng kết đúng giai đoạn bạn chọn.</p></div><button className="summary-share-entry" disabled={!included.length} onClick={() => onShare(kind, dates[kind])}><Icon name="share" size={16} />Chia sẻ tổng kết</button></div>
    <div className="period-filter"><div className="segmented" aria-label="Giai đoạn thống kê">{periodOptions.map(option => <button key={option.key} aria-pressed={kind === option.key} className={kind === option.key ? 'selected' : ''} onClick={() => { setKind(option.key); setSelectedBar(null) }}>{option.label}</button>)}</div><label>{kind === 'week' ? 'Tuần chứa ngày' : kind === 'month' ? 'Chọn tháng' : 'Chọn năm'}<input aria-label="Chọn giai đoạn thống kê" type={kind === 'week' ? 'date' : kind === 'month' ? 'month' : 'number'} min={kind === 'year' ? 2000 : undefined} max={kind === 'year' ? 2100 : undefined} value={dates[kind]} onChange={event => { setDates(current => ({ ...current, [kind]: event.target.value })); setSelectedBar(null) }} /></label></div>
    <p className="selected-period">{period?.label ?? 'Vui lòng chọn giai đoạn hợp lệ.'}</p>
    <div className="stats-grid statistics-cards">{cards.map(card => <div key={card.label} className="stat-card"><div className="stat-title"><span className={`stat-icon ${card.color}`}><Icon name={card.icon} size={17} /></span>{card.label}</div><div className="stat-value">{card.value}<small>{card.unit}</small></div></div>)}</div>
    {!included.length && <div className="empty-state">Chưa có hoạt động trong giai đoạn này. Dữ liệu mẫu hiện có từ 21–24/05/2025.</div>}
    <section className="weekly-card"><div className="section-bar"><div><h2>Đều đặn tạo nên khác biệt</h2><p>Quãng đường vận động theo {kind === 'year' ? 'tháng' : kind === 'month' ? 'nhóm ngày' : 'ngày'}</p></div><span className="chart-legend"><i /> Quãng đường · km</span></div><div className="bar-chart"><div className="axis-labels">{[1, 2 / 3, 1 / 3, 0].map((ratio, i) => <span key={i}>{number(maximum * ratio)}</span>)}</div><div className="bars">{buckets.map((bucket, i) => <button key={bucket.label} className={`bar-column ${selectedBar === i ? 'today' : ''}`} onClick={() => setSelectedBar(i)} aria-label={`${bucket.label}: ${number(bucket.value, 2)} km`}><div className="bar-track"><div className="bar-fill" style={{ height: `${bucket.value / maximum * 100}%` }}>{selectedBar === i && <span className="bar-tooltip">{number(bucket.value, 2)} km</span>}</div></div><span>{bucket.label}</span></button>)}</div></div><div className="chart-caption">Chạm vào cột để xem quãng đường. Tất cả số liệu được tính từ hoạt động trong giai đoạn này.</div></section>
    <div className="statistics-elevation"><h2>Độ cao tích lũy</h2><span>Tăng <strong>{totals.gain} m</strong></span><span>Giảm <strong>{totals.loss} m</strong></span></div>
    <p className="panel-footnote">Tốc độ trung bình = tổng quãng đường / tổng thời gian. Nhịp tim trung bình được tính theo thời gian vận động.</p>
  </div>
}
