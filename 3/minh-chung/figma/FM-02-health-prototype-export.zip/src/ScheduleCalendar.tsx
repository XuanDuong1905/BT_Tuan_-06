import { useEffect, useRef, useState } from "react"
import { Icon, type IconName } from "./ui"
import { ShareButton as Button, ShareHeading as Heading } from "./ShareControls"
import {
  calendarDate,
  calendarDays,
  scheduleDateLabel,
  schedulesOnDate,
  scheduleWeekdays,
  shiftMonth,
  vietnamToday,
  type Schedule,
} from "./scheduleCalendar"
import { formatShareNumber } from "./workoutSharing"
import "./schedule-calendar.css"

function DayWorkouts({
  schedules,
  date,
  today,
  onAdd,
  onEdit,
}: {
  schedules: Schedule[]
  date: string
  today: boolean
  onAdd: (date: string) => void
  onEdit: (schedule: Schedule) => void
}) {
  const rows = schedulesOnDate(schedules, date)
  return (
    <>
      <div className="section-bar schedule-day-heading">
        <div>
          <Heading level={3}>
            {today ? "Lịch tập hôm nay" : "Lịch tập ngày đã chọn"}
          </Heading>
          <p>
            <time dateTime={date}>{scheduleDateLabel(date)}</time>
          </p>
        </div>
        <span className="schedule-count">{rows.length} buổi tập</span>
      </div>
      {rows.length ? (
        <ol
          className="schedule-day-list"
          aria-label={
            today ? "Các buổi tập hôm nay" : "Các buổi tập ngày đã chọn"
          }
        >
          {rows.map((schedule) => (
            <li key={schedule.id}>
              <time
                className="schedule-day-time"
                dateTime={`${date}T${schedule.time}:00+07:00`}
              >
                {schedule.time}
              </time>
              <Button
                className="schedule-day-workout"
                onClick={() => onEdit(schedule)}
                aria-label={`Chỉnh sửa ${schedule.name}, ${schedule.time}`}
              >
                <span className="schedule-day-name">
                  {schedule.name}
                  <Icon name="chevron" size={14} />
                </span>
                <span className="schedule-day-type">
                  <Icon
                    name={
                      ({
                        "Đạp xe": "bike",
                        "Bơi lội": "swim",
                        "Đi bộ": "walk",
                        Khác: "activity",
                      } as Record<string, IconName>)[schedule.type] ?? "run"
                    }
                    size={14}
                  />
                  {schedule.type}
                </span>
                <span className="schedule-day-goal">
                  <Icon name="target" size={13} />
                  Mục tiêu: {formatShareNumber(schedule.goal)} {schedule.unit}
                </span>
                <span className="schedule-day-reminder">
                  <Icon name="bell" size={13} />
                  {schedule.reminder
                    ? `Nhắc trước ${schedule.minutes} phút`
                    : "Đã tắt nhắc nhở"}
                </span>
              </Button>
            </li>
          ))}
        </ol>
      ) : (
        <div className="schedule-day-empty">
          <span className="schedule-empty-icon">
            <Icon name="calendar" size={23} />
          </span>
          <strong>
            {today ? "Hôm nay chưa có lịch tập" : "Ngày này chưa có lịch tập"}
          </strong>
          <p>Dành một khoảng thời gian cho nhịp vận động của bạn.</p>
        </div>
      )}
      <Button className="schedule-add-date" onClick={() => onAdd(date)}>
        <Icon name="plus" size={16} />
        Thêm lịch tập{rows.length ? (today ? " hôm nay" : " ngày này") : ""}
      </Button>
    </>
  )
}

export default function ScheduleCalendar({
  schedules,
  onAdd,
  onEdit,
}: {
  schedules: Schedule[]
  onAdd: (date: string) => void
  onEdit: (schedule: Schedule) => void
}) {
  const [today, setToday] = useState(vietnamToday)
  const [selected, setSelected] = useState(today)
  const [month, setMonth] = useState(() => today.slice(0, 7))
  const todaySection = useRef<HTMLElement>(null)
  const calendar = useRef<HTMLDivElement>(null)
  useEffect(() => {
    const update = () => setToday(vietnamToday())
    const timer = setInterval(update, 60000)
    window.addEventListener("focus", update)
    return () => {
      clearInterval(timer)
      window.removeEventListener("focus", update)
    }
  }, [])
  const monthLabel = calendarDate(`${month}-01`).toLocaleDateString("vi-VN", {
    month: "long",
    year: "numeric",
    timeZone: "UTC",
  })
  const selectDate = (date: string) => {
    setSelected(date)
    setMonth(date.slice(0, 7))
    if (date === today)
      todaySection.current?.scrollIntoView({
        block: "nearest",
        behavior: matchMedia("(prefers-reduced-motion: reduce)").matches
          ? "instant"
          : "smooth",
      })
  }

  return (
    <div className="schedule-overview">
      <section
        className="schedule-today-card"
        ref={todaySection}
        aria-label="Lịch tập hôm nay"
      >
        <DayWorkouts
          schedules={schedules}
          date={today}
          today
          onAdd={onAdd}
          onEdit={onEdit}
        />
      </section>
      <section className="schedule-month-card" aria-label="Lịch tập theo tháng">
        <div className="section-bar">
          <div>
            <span className="schedule-kicker">ĐỀU ĐẶN THEO NHỊP CỦA BẠN</span>
            <Heading level={3}>Lịch tháng</Heading>
          </div>
          <Button
            className="schedule-today-button"
            onClick={() => selectDate(today)}
          >
            Hôm nay
          </Button>
        </div>
        <div className="schedule-month-toolbar">
          <Button
            className="schedule-month-arrow previous"
            aria-label="Tháng trước"
            onClick={() => setMonth(shiftMonth(month, -1))}
          >
            <Icon name="chevron" size={17} />
          </Button>
          <Heading level={4} id="schedule-month-label">
            {monthLabel}
          </Heading>
          <Button
            className="schedule-month-arrow"
            aria-label="Tháng sau"
            onClick={() => setMonth(shiftMonth(month, 1))}
          >
            <Icon name="chevron" size={17} />
          </Button>
        </div>
        <div className="schedule-weekdays" aria-hidden="true">
          {scheduleWeekdays.map((day) => (
            <span key={day}>{day}</span>
          ))}
        </div>
        <div
          className="schedule-calendar-grid"
          ref={calendar}
          role="group"
          aria-labelledby="schedule-month-label"
        >
          {calendarDays(month).map((date) => {
            const count = schedulesOnDate(schedules, date).length
            return (
              <Button
                key={date}
                className={`schedule-calendar-day ${
                  date.slice(0, 7) !== month ? "outside" : ""
                } ${date === today ? "is-today" : ""} ${
                  date === selected ? "is-selected" : ""
                }`}
                data-date={date}
                aria-current={date === today ? "date" : undefined}
                aria-pressed={date === selected}
                aria-label={`${scheduleDateLabel(date)}${
                  date === today ? ", hôm nay" : ""
                }, ${count ? `${count} buổi tập` : "chưa có lịch tập"}`}
                onClick={() => selectDate(date)}
                onKeyDown={(event) => {
                  const offset = {
                    ArrowLeft: -1,
                    ArrowRight: 1,
                    ArrowUp: -7,
                    ArrowDown: 7,
                  }[event.key]
                  if (!offset) return
                  event.preventDefault()
                  const next = calendarDate(date)
                  next.setUTCDate(next.getUTCDate() + offset)
                  const nextDate = next.toISOString().slice(0, 10)
                  selectDate(nextDate)
                  requestAnimationFrame(() =>
                    calendar.current
                      ?.querySelector<HTMLButtonElement>(
                        `[data-date="${nextDate}"]`,
                      )
                      ?.focus(),
                  )
                }}
              >
                <span>{Number(date.slice(-2))}</span>
                {!!count && <i className="schedule-dot" aria-hidden="true" />}
              </Button>
            )
          })}
        </div>
        <div className="schedule-calendar-legend">
          <span>
            <i className="schedule-dot" />
            Có lịch tập
          </span>
          <span className="schedule-today-legend">
            <i />
            Hôm nay
          </span>
        </div>
        <p className="schedule-calendar-hint">
          Bao gồm các buổi tập lặp lại. Chọn một ngày để xem lịch.
        </p>
      </section>
      {selected !== today && (
        <section
          className="schedule-selected-card"
          aria-label="Lịch tập ngày đã chọn"
          aria-live="polite"
        >
          <DayWorkouts
            schedules={schedules}
            date={selected}
            today={false}
            onAdd={onAdd}
            onEdit={onEdit}
          />
        </section>
      )}
    </div>
  )
}
