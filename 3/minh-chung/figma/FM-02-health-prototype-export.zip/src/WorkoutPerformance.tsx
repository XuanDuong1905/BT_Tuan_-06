import { useId, useState, type PointerEvent } from 'react'
import { workoutPerformance, type PerformanceWorkout } from './workoutPerformance'

const number = (value: number, digits = 1) => value.toLocaleString('vi-VN', { minimumFractionDigits: digits, maximumFractionDigits: digits })
const distance = (value: number) => value.toLocaleString('vi-VN', { maximumFractionDigits: 2 })
const time = (seconds: number) => {
  const total = Math.round(seconds)
  return `${Math.floor(total / 60).toString().padStart(2, '0')}:${(total % 60).toString().padStart(2, '0')}`
}

export function PerformanceSummary({ workout }: { workout: PerformanceWorkout }) {
  const data = workoutPerformance(workout)
  return <section className="performance-summary insight-summaries" aria-label="Tốc độ và nhịp tim trung bình">
    <div className="insight-summary speed-summary"><span>Tốc độ trung bình</span><strong>{number(data.averageSpeed)} <small>km/h</small></strong><p>Toàn bộ quãng đường · {workout.distance} km</p></div>
    <div className="insight-summary heart-summary"><span>Nhịp tim trung bình</span><strong>{number(data.averageHeartRate, 0)} <small>bpm</small></strong><p>Trung bình theo thời gian vận động</p></div>
  </section>
}

export function KilometerBreakdown({ workout }: { workout: PerformanceWorkout }) {
  const data = workoutPerformance(workout)
  return <section className="performance-splits" aria-label="Thống kê từng km">
      <h3>Thống kê từng km</h3>
      <p className="performance-splits-description">Mỗi hàng được tính riêng từ dữ liệu trong đoạn đó, không phải trung bình toàn buổi.</p>
      <table><thead><tr><th scope="col">Đoạn</th><th scope="col">Tốc độ trung bình<br /><span>km/h</span></th><th scope="col">Nhịp tim trung bình<br /><span>bpm</span></th></tr></thead>
        <tbody>{data.splits.map((split, index) => {
          const incomplete = split.endDistance - split.startDistance < 1 - 1e-9
          return <tr key={index}><th scope="row">{incomplete ? `${distance(split.startDistance)}–${distance(split.endDistance)} km` : `Km ${index + 1}`}<small>{incomplete ? `Đoạn cuối · ${distance(split.endDistance - split.startDistance)} km` : `${distance(split.startDistance)}–${distance(split.endDistance)} km`}</small></th><td>{number(split.speed)}</td><td>{number(split.heartRate, 0)}</td></tr>
        })}</tbody>
      </table>
      <p>Tốc độ = quãng đường / thời gian của đoạn. Nhịp tim được tính trung bình theo thời gian ghi nhận trong đoạn.</p>
    </section>
}

export default function WorkoutPerformance({ workout, metricOverride }: { workout: PerformanceWorkout; metricOverride?: 'speed' | 'heartRate' }) {
  const [storedMetric, setMetric] = useState<'speed' | 'heartRate'>('speed')
  const metric = metricOverride ?? storedMetric
  const [view, setView] = useState('time')
  const [inspectionFraction, setInspectionFraction] = useState(.5)
  const id = useId()
  const data = workoutPerformance(workout)
  const speed = metric === 'speed'
  const average = speed ? data.averageSpeed : data.averageHeartRate
  const unit = speed ? 'km/h' : 'bpm'
  const digits = speed ? 1 : 0
  const label = speed ? 'Tốc độ trung bình' : 'Nhịp tim trung bình'
  const series = view === 'time' ? data.segments : data.splits
  const values = [...series.map(s => s[metric]), average]
  const padding = speed ? Math.max(1, data.averageSpeed * .2) : 12
  const lower = Math.max(0, Math.floor(Math.min(...values) - padding))
  const upper = Math.ceil(Math.max(...values) + padding)
  const y = (value: number) => 150 - (value - lower) / (upper - lower) * 122
  const x = (value: number) => 36 + value / (view === 'time' ? data.duration : data.distance) * 312
  const path = series.map((segment, i) => {
    const start = view === 'time' ? segment.startTime : segment.startDistance
    const end = view === 'time' ? segment.endTime : segment.endDistance
    return `${i === 0 ? 'M' : 'L'}${x(start)},${y(segment[metric])} L${x(end)},${y(segment[metric])}`
  }).join(' ')
  const inspectedTime = inspectionFraction * data.duration
  const recordedSegment = data.segments.find(segment => inspectedTime < segment.endTime) ?? data.segments[data.segments.length - 1]
  const inspectedDistance = recordedSegment.startDistance + (inspectedTime - recordedSegment.startTime) * recordedSegment.speed / 3600
  const inspectedSegment = series.find(segment => inspectedTime < segment.endTime) ?? series[series.length - 1]
  const inspectedValue = inspectedSegment[metric]
  const inspectedX = x(view === 'time' ? inspectedTime : inspectedDistance)
  const inspectPointer = (event: PointerEvent<SVGSVGElement>) => {
    const bounds = event.currentTarget.getBoundingClientRect()
    const fraction = Math.max(0, Math.min(1, ((event.clientX - bounds.left) / bounds.width * 360 - 36) / 312))
    if (view === 'time') {
      setInspectionFraction(fraction)
    } else {
      const targetDistance = fraction * data.distance
      const segment = data.segments.find(item => targetDistance < item.endDistance) ?? data.segments[data.segments.length - 1]
      const elapsed = segment.startTime + (targetDistance - segment.startDistance) * 3600 / segment.speed
      setInspectionFraction(Math.max(0, Math.min(1, elapsed / data.duration)))
    }
  }

  return <section className={`performance-section ${speed ? 'speed-performance' : 'heart-performance'}`} aria-label="Thống kê tốc độ và nhịp tim">
    <div className="performance-controls">
      {!metricOverride && <div className="segmented" role="tablist" aria-label="Chọn chỉ số" onKeyDown={event => {
        if (!['ArrowLeft', 'ArrowRight', 'Home', 'End'].includes(event.key)) return
        event.preventDefault()
        const next = event.key === 'Home' ? 'speed' : event.key === 'End' ? 'heartRate' : speed ? 'heartRate' : 'speed'
        setMetric(next)
        event.currentTarget.querySelector<HTMLButtonElement>(`[data-metric="${next}"]`)?.focus()
      }}>
        <button id={`${id}-speed-tab`} data-metric="speed" role="tab" tabIndex={speed ? 0 : -1} aria-selected={speed} aria-controls={`${id}-chart-panel`} className={speed ? 'selected' : ''} onClick={() => setMetric('speed')}>Tốc độ</button>
        <button id={`${id}-heartRate-tab`} data-metric="heartRate" role="tab" tabIndex={!speed ? 0 : -1} aria-selected={!speed} aria-controls={`${id}-chart-panel`} className={!speed ? 'selected' : ''} onClick={() => setMetric('heartRate')}>Nhịp tim</button>
      </div>}
      <label className="performance-view">Hiển thị
        <select value={view} onChange={e => setView(e.target.value)}><option value="time">Theo thời gian</option><option value="kilometer">Từng kilômét</option></select>
      </label>
    </div>
    <div id={`${id}-chart-panel`} role={metricOverride ? undefined : 'tabpanel'} aria-labelledby={metricOverride ? undefined : `${id}-${metric}-tab`}>
    <div className="performance-average"><span>{label} toàn buổi</span><strong>{number(average, digits)} <small>{unit}</small></strong></div>
    <div className="performance-inspection" aria-live="polite" aria-atomic="true">
      <span><strong>{time(inspectedTime)}</strong><small>đã trôi qua · {distance(inspectedDistance)} km</small></span>
      <span><strong>{number(inspectedValue, digits)} <small>{unit}</small></strong><small>{view === 'time' ? (speed ? 'Tốc độ tại thời điểm chọn' : 'Nhịp tim tại thời điểm chọn') : 'Trung bình đoạn đang chọn'}</small></span>
    </div>
    <svg className="performance-chart" viewBox="0 0 360 190" role="slider" tabIndex={0}
      aria-label={`${speed ? 'Tốc độ' : 'Nhịp tim'} ${view === 'time' ? 'theo thời gian' : 'từng kilômét'}`}
      aria-valuemin={0} aria-valuemax={Math.round(data.duration)} aria-valuenow={Math.round(inspectedTime)}
      aria-valuetext={`${time(inspectedTime)}, ${number(inspectedValue, digits)} ${unit}, ${distance(inspectedDistance)} km`}
      aria-describedby={`${id}-inspection-hint`}
      onPointerDown={event => { event.currentTarget.focus({ preventScroll: true }); event.currentTarget.setPointerCapture(event.pointerId); inspectPointer(event) }}
      onPointerMove={event => { if (event.currentTarget.hasPointerCapture(event.pointerId) || event.pointerType === 'mouse') inspectPointer(event) }}
      onPointerUp={event => { if (event.currentTarget.hasPointerCapture(event.pointerId)) event.currentTarget.releasePointerCapture(event.pointerId) }}
      onKeyDown={event => {
        if (!['ArrowLeft', 'ArrowRight', 'Home', 'End'].includes(event.key)) return
        event.preventDefault()
        setInspectionFraction(current => event.key === 'Home' ? 0 : event.key === 'End' ? 1 : Math.max(0, Math.min(1, current + (event.key === 'ArrowRight' ? .01 : -.01))))
      }}>
      <defs><linearGradient id={`${id}-performance-fill`} x1="0" x2="0" y1="0" y2="1"><stop offset="0" stopColor="currentColor" stopOpacity=".2" /><stop offset="1" stopColor="currentColor" stopOpacity=".02" /></linearGradient></defs>
      {[0, .5, 1].map(f => <g key={f}><line x1="36" x2="348" y1={150 - f * 122} y2={150 - f * 122} className="insight-grid" /><text x="29" y={153 - f * 122} textAnchor="end" className="insight-axis">{number(lower + f * (upper - lower), speed ? 1 : 0)}</text></g>)}
      <text x="36" y="13" className="insight-axis">{unit}</text>
      <path d={`${path} L348,150 L36,150 Z`} fill={`url(#${id}-performance-fill)`} />
      <path d={path} fill="none" stroke="currentColor" strokeWidth="2" strokeLinejoin="round" />
      <line x1="36" x2="348" y1={y(average)} y2={y(average)} className="performance-reference" />
      <rect x="190" y={y(average) - 17} width="158" height="14" rx="3" className="performance-reference-label" />
      <text x="343" y={y(average) - 7} textAnchor="end" className="performance-reference-text">Trung bình: {number(average, digits)} {unit}</text>
      <line x1={inspectedX} x2={inspectedX} y1="25" y2="150" className="performance-crosshair" />
      <circle cx={inspectedX} cy={y(inspectedValue)} r="4" fill="currentColor" stroke="white" strokeWidth="2" />
      {[0, .25, .5, .75, 1].map(f => <text key={f} x={36 + f * 312} y="168" textAnchor={f === 0 ? 'start' : f === 1 ? 'end' : 'middle'} className="insight-axis">{view === 'time' ? time(data.duration * f) : number(data.distance * f, 2)}</text>)}
      <text x="348" y="185" textAnchor="end" className="insight-axis">{view === 'time' ? 'Thời gian (phút:giây)' : 'Quãng đường (km)'}</text>
    </svg>
    <p id={`${id}-inspection-hint`} className="performance-chart-note">Chạm hoặc kéo trên biểu đồ để xem thời gian và giá trị. Có thể dùng phím mũi tên trái/phải.</p>
    <p className="performance-chart-note">Đường nét đứt: trung bình toàn buổi{view === 'kilometer' ? ' · Biểu đồ thể hiện trung bình từng đoạn' : ''}.</p>
    </div>

  </section>
}
