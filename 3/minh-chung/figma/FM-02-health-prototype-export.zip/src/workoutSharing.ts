import { elevationStats, workoutSamples } from "./WorkoutInsights"
import { workoutPerformance } from "./workoutPerformance"

export type ShareWorkout = {
  name: string
  type: string
  isoDate: string
  time: string
  icon: string
  distance: string
  duration: string
  calories: number
}
export type PeriodKind = "week" | "month" | "year"
export type ShareKey = "name" | "type" | "date" | "time" | "count" | "distance" | "duration" | "calories" | "speed" | "heart" | "elevation" | "map" | "speedChart" | "heartChart" | "elevationChart" | "splits"
export const shareOptions: {
  key: ShareKey
  label: string
  singleOnly?: boolean
  summaryOnly?: boolean
}[] = [
  { key: "name", label: "Tên hoạt động", singleOnly: true },
  { key: "type", label: "Loại hoạt động", singleOnly: true },
  { key: "date", label: "Ngày tập / Giai đoạn tổng kết" },
  { key: "time", label: "Giờ bắt đầu", singleOnly: true },
  { key: "count", label: "Số buổi tập", summaryOnly: true },
  { key: "distance", label: "Quãng đường" },
  { key: "duration", label: "Thời gian vận động" },
  { key: "calories", label: "Calo tiêu thụ" },
  { key: "speed", label: "Tốc độ trung bình" },
  { key: "heart", label: "Nhịp tim trung bình" },
  { key: "elevation", label: "Thống kê độ cao" },
  { key: "map", label: "Bản đồ lộ trình", singleOnly: true },
  { key: "speedChart", label: "Biểu đồ tốc độ", singleOnly: true },
  { key: "heartChart", label: "Biểu đồ nhịp tim", singleOnly: true },
  { key: "elevationChart", label: "Biểu đồ độ cao", singleOnly: true },
  { key: "splits", label: "Thống kê từng km", singleOnly: true },
]
export const formatShareNumber = (value: number, digits = 1) =>
  value.toLocaleString("vi-VN", { maximumFractionDigits: digits })
const dateLabel = (date: Date) =>
  date.toLocaleDateString("vi-VN", { timeZone: "UTC" })
const iso = (date: Date) => date.toISOString().slice(0, 10)
export function sharingPeriod(kind: PeriodKind, value: string) {
  const pattern =
    kind === "week"
      ? /^\d{4}-\d{2}-\d{2}$/
      : kind === "month"
        ? /^\d{4}-\d{2}$/
        : /^\d{4}$/
  if (!pattern.test(value)) return null
  const start = new Date(
    `${
      kind === "year"
        ? `${value}-01-01`
        : kind === "month"
          ? `${value}-01`
          : value
    }T00:00:00Z`,
  )
  if (!Number.isFinite(start.getTime())) return null
  if (kind === "week" && iso(start) !== value) return null
  const end = new Date(start)
  if (kind === "week") {
    start.setUTCDate(start.getUTCDate() - ((start.getUTCDay() + 6) % 7))
    end.setTime(start.getTime())
    end.setUTCDate(end.getUTCDate() + 7)
  }
  if (kind === "month") end.setUTCMonth(end.getUTCMonth() + 1)
  if (kind === "year") end.setUTCFullYear(end.getUTCFullYear() + 1)
  const lastDay = new Date(end.getTime() - 86400000)
  const label =
    kind === "week"
      ? `Tuần ${dateLabel(start)} – ${dateLabel(lastDay)}`
      : kind === "month"
        ? `Tháng ${start.getUTCMonth() + 1}/${start.getUTCFullYear()}`
        : `Năm ${start.getUTCFullYear()}`
  return {
    start: iso(start),
    end: iso(end),
    label,
    rangeLabel: `${dateLabel(start)} – ${dateLabel(lastDay)}`,
  }
}
export function workoutsInPeriod(
  workouts: ShareWorkout[],
  kind: PeriodKind,
  value: string,
) {
  const period = sharingPeriod(kind, value)
  return period
    ? workouts.filter(
        (w) => w.isoDate >= period.start && w.isoDate < period.end,
      )
    : []
}
export function shareTotals(workouts: ShareWorkout[]) {
  const data = workouts.map((w) => ({
    performance: workoutPerformance(w),
    elevation: elevationStats(workoutSamples(w)),
    calories: w.calories,
  }))
  const distance = data.reduce((sum, w) => sum + w.performance.distance, 0)
  const duration = data.reduce((sum, w) => sum + w.performance.duration, 0)
  return {
    count: workouts.length,
    distance,
    duration,
    calories: data.reduce((sum, w) => sum + w.calories, 0),
    speed: duration ? (distance * 3600) / duration : 0,
    heart: duration
      ? data.reduce(
          (sum, w) =>
            sum + w.performance.averageHeartRate * w.performance.duration,
          0,
        ) / duration
      : 0,
    gain: data.reduce((sum, w) => sum + w.elevation.gain, 0),
    loss: data.reduce((sum, w) => sum + w.elevation.loss, 0),
    min: data.length ? Math.min(...data.map((w) => w.elevation.min)) : 0,
    max: data.length ? Math.max(...data.map((w) => w.elevation.max)) : 0,
  }
}
const elapsed = (seconds: number) =>
  `${Math.floor(seconds / 3600)
    .toString()
    .padStart(2, "0")}:${Math.floor((seconds % 3600) / 60)
    .toString()
    .padStart(2, "0")}:${Math.round(seconds % 60)
    .toString()
    .padStart(2, "0")}`
type Field = {
  key: ShareKey
  label: string
  value: string
}
type Chart = {
  label: string
  unit: string
  points: {
    x: number
    y: number
  }[]
  average?: number
  duration: number
  showDuration: boolean
}
export type ShareContent = {
  summaryTitle?: string
  fields: Field[]
  charts: Chart[]
  map: boolean
  splitHeaders: string[]
  splits: string[][]
  caption: string
}

export function buildShareContent(
  workouts: ShareWorkout[],
  selected: Set<ShareKey>,
  single: boolean,
  periodLabel: string,
  periodKind: PeriodKind = "week",
): ShareContent {
  const total = shareTotals(workouts)
  const workout = workouts[0]
  const fields: Field[] = []
  const add = (key: ShareKey, label: string, value: string) => {
    if (selected.has(key)) fields.push({ key, label, value })
  }
  if (single && workout) {
    add("name", "Hoạt động", workout.name)
    add("type", "Loại hoạt động", workout.type)
  }
  add(
    "date",
    single ? "Ngày tập" : "Giai đoạn",
    single && workout
      ? dateLabel(new Date(`${workout.isoDate}T00:00:00Z`))
      : periodLabel,
  )
  if (single && workout) add("time", "Giờ bắt đầu", workout.time)
  if (!single) add("count", "Số buổi tập", `${total.count} buổi`)
  add(
    "distance",
    single ? "Quãng đường" : "Tổng quãng đường",
    `${formatShareNumber(total.distance, 2)} km`,
  )
  add(
    "duration",
    single ? "Thời gian vận động" : "Tổng thời gian",
    elapsed(total.duration),
  )
  add(
    "calories",
    "Calo tiêu thụ",
    `${formatShareNumber(total.calories, 0)} kcal`,
  )
  add("speed", "Tốc độ trung bình", `${formatShareNumber(total.speed)} km/h`)
  add(
    "heart",
    "Nhịp tim trung bình",
    `${formatShareNumber(total.heart, 0)} bpm`,
  )
  add(
    "elevation",
    "Độ cao",
    `Tăng ${total.gain} m · Giảm ${total.loss} m · Thấp nhất ${total.min} m · Cao nhất ${total.max} m`,
  )
  const charts: Chart[] = []
  const splits: string[][] = []
  const splitHeaders = [
    "Đoạn",
    ...(selected.has("speed") ? ["Tốc độ TB"] : []),
    ...(selected.has("heart") ? ["Nhịp tim TB"] : []),
  ]
  if (single && workout) {
    const data = workoutPerformance(workout)
    for (const [key, metric, label, unit, averageKey] of [
      ["speedChart", "speed", "Biểu đồ tốc độ", "km/h", "speed"],
      ["heartChart", "heartRate", "Biểu đồ nhịp tim", "bpm", "heart"],
    ] as const) {
      if (selected.has(key))
        charts.push({
          label,
          unit,
          duration: data.duration,
          showDuration: selected.has("duration"),
          points: data.segments.flatMap((segment) => [
            { x: segment.startTime, y: segment[metric] },
            { x: segment.endTime, y: segment[metric] },
          ]),
          average: selected.has(averageKey)
            ? metric === "speed"
              ? data.averageSpeed
              : data.averageHeartRate
            : undefined,
        })
    }
    if (selected.has("elevationChart"))
      charts.push({
        label: "Biểu đồ độ cao",
        unit: "m",
        duration: data.duration,
        showDuration: selected.has("duration"),
        points: workoutSamples(workout).map((s) => ({
          x: s.seconds,
          y: s.elevation,
        })),
      })
    if (selected.has("splits"))
      data.splits.forEach((split, i) =>
        splits.push([
          selected.has("distance")
            ? split.endDistance - split.startDistance < 1 - 1e-9
              ? `${formatShareNumber(split.startDistance)}–${formatShareNumber(split.endDistance, 2)} km`
              : `Km ${i + 1}`
            : `Đoạn ${i + 1}`,
          ...(selected.has("speed")
            ? [`${formatShareNumber(split.speed)} km/h`]
            : []),
          ...(selected.has("heart")
            ? [`${formatShareNumber(split.heartRate, 0)} bpm`]
            : []),
        ]),
      )
  }
  const map = single && !!workout && selected.has("map")
  const summaryTitle = single
    ? undefined
    : `Tổng kết ${
        periodKind === "week"
          ? "tuần"
          : periodKind === "month"
            ? "tháng"
            : "năm"
      }`
  const caption = [
    ...(summaryTitle ? [summaryTitle] : []),
    ...fields.map((f) => `${f.label}: ${f.value}`),
    ...(map ? ["Bản đồ lộ trình minh họa"] : []),
    ...charts.map((chart) => chart.label),
    ...(splits.length
      ? [
          `Chi tiết từng đoạn (${splitHeaders.join(" · ")})`,
          ...splits.map((row) => row.join(" · ")),
        ]
      : []),
  ].join("\n")
  return { summaryTitle, fields, charts, map, splitHeaders, splits, caption }
}

const escapeXml = (text: string) =>
  text.replace(
    /[<>&"']/g,
    (character) =>
      ({
        "<": "&lt;",
        ">": "&gt;",
        "&": "&amp;",
        '"': "&quot;",
        "'": "&apos;",
      })[character]!,
  )
export function renderShareSvg(
  content: ShareContent,
  layout: "square" | "story",
) {
  const story = layout === "story"
  const height = story ? 960 : 540
  const width = 476
  const palette = {
    ink: "#273831",
    green: "#327b59",
    muted: "#62766a",
    line: "#e2e8df",
    soft: "#edf3e9",
    paper: "#fafbf6",
  }
  let y = 0
  const blocks: string[] = []
  const text = (
    x: number,
    top: number,
    value: string,
    size = 12,
    color = palette.ink,
    weight = 400,
  ) =>
    `<text x="${x}" y="${top}" font-size="${size}" fill="${color}" font-weight="${weight}">${escapeXml(value)}</text>`
  const wrap = (value: string, max = 34) => {
    const lines: string[] = []
    let line = ""
    value.split(" ").forEach((word) => {
      if (`${line} ${word}`.trim().length > max && line) {
        lines.push(line)
        line = word
      } else line = `${line} ${word}`.trim()
    })
    if (line) lines.push(line)
    return lines
  }
  const field = (key: ShareKey) =>
    content.fields.find((item) => item.key === key)
  const metricIcon = (key: ShareKey, x: number, top: number) => {
    const paths: Partial<Record<ShareKey, string>> = {
      distance: "M2 10 5 2l4 8 3-8",
      speed: "M1 7h3l2-5 3 10 2-5h3",
      duration: "M7 3v4l2 1M7 1a6 6 0 1 0 0 12A6 6 0 0 0 7 1",
      count: "M1 1h5v5H1zM9 1h5v5H9zM1 9h5v5H1zM9 9h5v5H9z",
      calories: "M7 1c1 4 5 4 5 8a5 5 0 0 1-10 0c0-2 1-4 2-5 0 3 2 3 3-3Z",
      heart: "M7 4C4-1-2 3 2 8l5 5 5-5C16 3 10-1 7 4Z",
    }
    return paths[key]
      ? `<g transform="translate(${x} ${top})" fill="none" stroke="${palette.muted}" stroke-width="1.1" stroke-linecap="round" stroke-linejoin="round"><path d="${paths[key]}"/></g>`
      : ""
  }
  const type = field("type")
  if (type) {
    blocks.push(
      `<rect width="${Math.max(86, type.value.length * 9 + 24)}" height="24" rx="12" fill="${palette.soft}"/>`,
      text(
        12,
        y + 16,
        type.value.toLocaleUpperCase("vi-VN"),
        12,
        palette.green,
        700,
      ),
    )
    y += story ? 36 : 30
  }
  const title = field("name")?.value ?? content.summaryTitle
  if (title) {
    const lines = wrap(title, 31)
    lines.forEach((line) => {
      blocks.push(text(0, y + 26, line, 28, palette.ink, 700))
      y += 34
    })
    if (story) y += 3
  }
  const date = field("date"),
    time = field("time")
  if (date || time) {
    blocks.push(
      text(
        0,
        y + 14,
        [date?.value, time?.value].filter(Boolean).join("  ·  "),
        15,
        palette.muted,
      ),
    )
    y += story ? 40 : 30
  }

  const primaryKeys: ShareKey[] = ["distance", "speed", "duration", "count"]
  const primary = primaryKeys.map(field).filter((item): item is Field => !!item)
  const hero = primary[0]
  const metricValue = (
    item: Field,
    x: number,
    top: number,
    size: number,
    unitSize: number,
  ) => {
    const parts = item.value.match(/^(.*?) (km\/h|km|buổi)$/)
    return parts
      ? `<text x="${x}" y="${top}" font-size="${size}" font-weight="600" fill="${palette.green}" letter-spacing="-2">${escapeXml(parts[1])}<tspan dx="9" font-size="${unitSize}" font-weight="450" letter-spacing="0" fill="${palette.muted}">${escapeXml(parts[2])}</tspan></text>`
      : text(x, top, item.value, size, palette.green, 600)
  }
  if (hero) {
    const sparse =
      content.fields.length <= 3 &&
      !content.map &&
      !content.charts.length &&
      !content.splits.length
    const size = hero.key === "duration" ? 68 : sparse ? 132 : story ? 112 : 88
    const numericValue = hero.value.split(" ")[0]
    const fittedSize = Math.min(
      size,
      (width - 80) / (numericValue.length * 0.6),
    )
    blocks.push(
      metricIcon(hero.key, 0, y + 4),
      text(22, y + 17, hero.label, 15, palette.muted),
      metricValue(hero, 0, y + fittedSize + 25, fittedSize, 30),
    )
    y += fittedSize + (story ? 58 : 40)
  }
  const supporting = primary.slice(1)
  if (supporting.length) {
    const columnWidth = width / supporting.length
    blocks.push(`<path d="M0 ${y}H${width}" stroke="${palette.line}"/>`)
    y += 13
    supporting.forEach((item, column) => {
      const x = column * columnWidth + (column ? 14 : 0)
      if (column)
        blocks.push(
          `<path d="M${column * columnWidth} ${y + 3}v44" stroke="${palette.line}"/>`,
        )
      blocks.push(
        text(
          x,
          y + 12,
          item.label,
          supporting.length === 3 ? 13 : 15,
          palette.muted,
        ),
      )
      blocks.push(
        metricValue(item, x, y + 42, supporting.length === 3 ? 24 : 30, 14),
      )
    })
    y += story ? 86 : 62
  }
  const secondary = content.fields.filter((item) =>
    ["calories", "heart", "elevation"].includes(item.key),
  )
  if (secondary.length) {
    const regular = secondary.filter((item) => item.key !== "elevation")
    const elevation = field("elevation")
    const regularHeight = story ? 70 : 62
    const elevationHeight = story ? 70 : 60
    const sectionHeight =
      (regular.length ? regularHeight : 0) + (elevation ? elevationHeight : 0)
    blocks.push(
      `<rect x="0" y="${y}" width="${width}" height="${sectionHeight}" rx="12" fill="${palette.soft}"/>`,
    )
    regular.forEach((item, column) => {
      const x = 16 + column * (width / regular.length)
      blocks.push(metricIcon(item.key, x, y + 12))
      blocks.push(text(x + 22, y + 23, item.label, 14, palette.muted))
      blocks.push(text(x, y + 49, item.value, 23, palette.ink, 600))
    })
    if (elevation) {
      const top = y + (regular.length ? regularHeight : 0)
      if (regular.length)
        blocks.push(
          `<path d="M16 ${top}H${width - 16}" stroke="${palette.line}"/>`,
        )
      const values = elevation.value.split(" · ")
      values.forEach((value, column) => {
        const x = 16 + column * ((width - 32) / values.length)
        const parts = value.match(/^(.*?) (\d+ m)$/)
        blocks.push(
          text(x, top + 23, parts?.[1] ?? elevation.label, 12, palette.muted),
          text(x, top + 46, parts?.[2] ?? value, 19, palette.ink, 600),
        )
      })
    }
    y += sectionHeight + (story ? 26 : 12)
  }
  if (content.map) {
    const mapHeight = story ? 240 : 116
    blocks.push(
      `<svg x="0" y="${y}" width="${width}" height="${mapHeight}" viewBox="0 0 476 ${mapHeight}"><rect width="${width}" height="${mapHeight}" rx="12" fill="#e8eee1"/><path d="M320-10Q230 35 285 90T305 250" fill="none" stroke="#c4ded7" stroke-width="48"/><g stroke="${palette.paper}" stroke-width="8"><path d="M0 20 476 90M95 0 160 250M410 0 345 250M0 140 476 15M0 65 476 145"/></g><g transform="translate(108 ${mapHeight / 2 - 53})"><path d="M45 85 20 40 86 10 155 40 141 91 86 106Z" fill="none" stroke="${palette.paper}" stroke-width="10" stroke-linejoin="round"/><path d="M45 85 20 40 86 10 155 40 141 91 86 106Z" fill="none" stroke="${palette.green}" stroke-width="4" stroke-linejoin="round"/><circle cx="45" cy="85" r="5" fill="${palette.green}" stroke="${palette.paper}" stroke-width="3"/></g></svg><rect x="9" y="${y + mapHeight - 27}" width="185" height="20" rx="5" fill="${palette.paper}" fill-opacity=".96"/>${text(17, y + mapHeight - 13, "Bản đồ lộ trình minh họa", 12, palette.muted)}`,
    )
    y += mapHeight + (story ? 25 : 12)
  }
  const chartColumns = !story && content.charts.length > 1 ? 2 : 1
  const chartWidth = (width - (chartColumns - 1) * 16) / chartColumns
  const chartStart = y
  content.charts.forEach((chart, index) => {
    const chartLeft = (index % chartColumns) * (chartWidth + 16)
    const chartTop = chartStart + Math.floor(index / chartColumns) * 130
    const min = Math.max(0, Math.min(...chart.points.map((p) => p.y)) - 2)
    const max = Math.max(...chart.points.map((p) => p.y)) + 3
    const chartY = (value: number) => 80 - ((value - min) / (max - min)) * 48
    const path = chart.points
      .map(
        (p, i) =>
          `${
            i ? "L" : "M"
          }${30 + (p.x / Math.max(1, chart.duration)) * (chartWidth - 38)},${chartY(p.y)}`,
      )
      .join(" ")
    blocks.push(
      `<g transform="translate(${chartLeft} ${chartTop})">${text(0, 15, `${chart.label} (${chart.unit})`, chartColumns === 2 ? 12 : 15, palette.ink, 550)}<path d="M30 40H${chartWidth - 8}M30 88H${chartWidth - 8}" stroke="${palette.line}"/>${text(0, 44, formatShareNumber(max, 0), 11)}${text(0, 91, formatShareNumber(min, 0), 11)}<path d="${path}" transform="translate(0 8)" fill="none" stroke="${
        chart.unit === "bpm" ? "#be8276" : "#5c9473"
      }" stroke-width="2"/>${
        chart.average !== undefined
          ? `<path d="M30 ${chartY(chart.average) + 8}H${chartWidth - 8}" stroke="${palette.muted}" stroke-dasharray="4 3"/>${text(30, 33, `Trung bình: ${formatShareNumber(chart.average, chart.unit === "bpm" ? 0 : 1)} ${chart.unit}`, 11)}`
          : ""
      }${
        chart.showDuration
          ? text(30, 110, "00:00", 11, palette.muted) +
            text(
              chartWidth - 62,
              110,
              elapsed(chart.duration),
              11,
              palette.muted,
            )
          : text(30, 110, "Diễn biến buổi tập", 11, palette.muted)
      }</g>`,
    )
  })
  y += Math.ceil(content.charts.length / chartColumns) * 130
  if (content.splits.length) {
    blocks.push(
      text(0, y + 16, "Chi tiết từng đoạn", 15, palette.ink, 600),
      ...content.splitHeaders.map((label, column) =>
        text(
          column * (width / content.splitHeaders.length) + 10,
          y + 40,
          label,
          13,
          palette.muted,
        ),
      ),
    )
    y += 56
    content.splits.forEach((row, i) => {
      blocks.push(
        `<rect x="0" y="${y - 16}" width="${width}" height="28" rx="4" fill="${
          i % 2 ? palette.paper : palette.soft
        }"/>${row.map((value, column) => text(column * (width / content.splitHeaders.length) + 10, y + 3, value, 13)).join("")}`,
      )
      y += 29
    })
  }
  const availableHeight = height - 110
  const scale = Math.min(1, availableHeight / Math.max(1, y))
  const offset = (width - width * scale) / 2
  const top = 76 + Math.max(0, (availableHeight - y * scale) / 2)
  return `<svg xmlns="http://www.w3.org/2000/svg" width="1080" height="${
    layout === "square" ? 1080 : 1920
  }" viewBox="0 0 540 ${height}"><rect width="540" height="${height}" fill="${palette.paper}"/><g font-family="Arial, sans-serif">${text(32, 39, "nhịp.", 27, palette.green, 700)}${text(357, 35, "THEO NHỊP CỦA BẠN", 12, palette.muted)}<path d="M32 57H508" stroke="${palette.line}"/><g transform="translate(${32 + offset} ${top}) scale(${scale})">${blocks.join("")}</g><path d="M32 ${height - 25}H508" stroke="${palette.line}"/>${text(32, height - 10, "Dữ liệu mẫu · Mỗi chuyển động, một bước tiến", 10, palette.muted)}</g></svg>`
}
