export type IconName = 'grid' | 'activity' | 'calendar' | 'target' | 'watch' | 'chevron' | 'arrow' | 'bell' | 'plus' | 'run' | 'walk' | 'bike' | 'swim' | 'heart' | 'clock' | 'distance' | 'check' | 'bluetooth' | 'close' | 'share'
export function Icon({ name, size = 21 }: { name: IconName; size?: number }) {
  const paths: Record<IconName, React.ReactNode> = {
    grid: <><rect x="3" y="3" width="7" height="7" rx="2" /><rect x="14" y="3" width="7" height="7" rx="2" /><rect x="3" y="14" width="7" height="7" rx="2" /><rect x="14" y="14" width="7" height="7" rx="2" /></>,
    activity: <path d="M3 13h4l3-9 4 16 3-7h4" />,
    calendar: <><rect x="3" y="5" width="18" height="16" rx="3" /><path d="M7 3v4m10-4v4M3 11h18m-13 4h1m6 0h1" /></>,
    target: <><circle cx="12" cy="12" r="9" /><circle cx="12" cy="12" r="5" /><circle cx="12" cy="12" r="1" /></>,
    watch: <><rect x="5" y="6" width="14" height="12" rx="4" /><path d="M8 6V2h8v4M8 18v4h8v-4m-4-9v3l2 1" /></>,
    chevron: <path d="m9 5 7 7-7 7" />, arrow: <path d="M5 12h14m-5-5 5 5-5 5" />,
    bell: <><path d="M5 17h14l-2-4V9a5 5 0 0 0-10 0v4Zm5 3h4" /></>,
    plus: <path d="M12 5v14M5 12h14" />,
    run: <><circle cx="15" cy="4" r="2" /><path d="m8 9 4-3 4 5 4 1M12 7l-2 7 5 3-1 5m-4-8-4 5H2" /></>,
    walk: <><circle cx="13" cy="4" r="2" /><path d="m6 12 5-4 4 4 4 1m-8-5-1 8-4 6m4-6 5 6" /></>,
    bike: <><circle cx="5.5" cy="16.5" r="4" /><circle cx="18.5" cy="16.5" r="4" /><path d="m6 16 5-9 7 9M9 7h5m1-4h3l2 5m-9-1 3 9H6" /></>,
    swim: <><circle cx="17" cy="7" r="2" /><path d="m4 12 6-6 5 6M7 4l3 2M2 17q3-4 6 0 3-4 6 0 3-4 8 0M2 21q3-4 6 0 3-4 6 0 3-4 8 0" /></>,
    heart: <path d="M20 5c-3-3-7-1-8 2-1-3-5-5-8-2-4 4 1 9 8 15 7-6 12-11 8-15Z" />,
    clock: <><circle cx="12" cy="12" r="9" /><path d="M12 7v5l3 2" /></>,
    distance: <><path d="m4 18 5-12 6 12 5-12" /><circle cx="4" cy="18" r="2" /><circle cx="20" cy="6" r="2" /></>,
    check: <path d="m5 12 4 4L19 6" />,
    bluetooth: <path d="m7 7 10 10-5 5V2l5 5L7 17" />,
    close: <path d="m6 6 12 12M6 18 18 6" />,
    share: <><path d="M12 15V3m-4 4 4-4 4 4M5 12v8h14v-8" /></>,
  }
  return <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round">{paths[name]}</svg>
}

export function RouteMap() {
  return <div className="route-map"><svg viewBox="0 0 600 270" preserveAspectRatio="xMidYMid slice"><rect width="600" height="270" fill="#eef0e8" /><path d="M320-20C220 35 400 90 310 145S250 210 335 300" fill="none" stroke="#c4e2df" strokeWidth="85" /><g fill="#dde7d1"><path d="M20 10h130v65H20zM430 160h140v110H430zM40 180h120v100H40zM420 10h120v65H420z" /></g><g stroke="#fff" strokeWidth="10" fill="none"><path d="M-20 100 610 160M90-10l100 300M460-20 380 300M-10 230 620 40M-10 25 620 245" /><path d="M30-10 45 280M540-10 525 280" strokeWidth="5" /></g><g fontSize="10" fill="#9baba5"><text x="55" y="147">THỤY KHUÊ</text><text x="290" y="100">HỒ TÂY</text><text x="425" y="225">TRÚC BẠCH</text><text x="425" y="50">YÊN PHỤ</text></g><path d="m206 185-28-59 44-48 61-17 61 29 38 50-16 60-62 26-58-17Z" fill="none" stroke="#fff" strokeWidth="10" strokeLinejoin="round" /><path d="m206 185-28-59 44-48 61-17 61 29 38 50-16 60-62 26-58-17Z" fill="none" stroke="#279168" strokeWidth="5" strokeLinejoin="round" /><circle cx="206" cy="185" r="8" fill="#269269" stroke="white" strokeWidth="4" /></svg><span className="map-label"><span className="live-dot" /> Hà Nội, Việt Nam</span><span className="map-scale"> ━━━ 500 m</span></div>
}

