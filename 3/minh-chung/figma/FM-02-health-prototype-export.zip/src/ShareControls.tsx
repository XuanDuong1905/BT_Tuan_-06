import { createElement, type ComponentProps } from "react"

// Small, semantic controls for the sharing flow; styling stays in sharing.css.
export function ShareButton(props: ComponentProps<"button">) {
  return createElement("button", { type: "button", ...props })
}

export function ShareHeading({
  level = 3,
  ...props
}: ComponentProps<"h2"> & { level?: 2 | 3 | 4 }) {
  return createElement(`h${level}`, props)
}

export function ShareInput(props: ComponentProps<"input">) {
  return createElement("input", props)
}
