import { workoutSamples } from './WorkoutInsights'

export type PerformanceWorkout = { icon: string; duration: string; distance: string; calories: number }
export type PerformanceSegment = {
  startTime: number
  endTime: number
  startDistance: number
  endDistance: number
  speed: number
  heartRate: number
}

export function workoutPerformance(workout: PerformanceWorkout) {
  const samples = workoutSamples(workout)
  const heartRates: Record<string, number[]> = {
    run: [122, 130, 137, 140, 144, 146, 148, 150, 149, 147, 146, 145],
    bike: [108, 116, 123, 129, 133, 136, 139, 141, 138, 135, 131, 127],
    walk: [86, 90, 94, 98, 101, 104, 106, 108, 105, 102, 99, 95],
    swim: [108, 116, 124, 129, 134, 138, 140, 142, 139, 136, 132, 128],
  }
  const segments: PerformanceSegment[] = samples.slice(1).map((sample, i) => ({
    startTime: samples[i].seconds,
    endTime: sample.seconds,
    startDistance: samples[i].distance,
    endDistance: sample.distance,
    speed: (sample.distance - samples[i].distance) * 3600 / (sample.seconds - samples[i].seconds),
    heartRate: (heartRates[workout.icon] ?? heartRates.run)[i],
  }))
  const last = samples[samples.length - 1]
  const averageHeartRate = segments.reduce((sum, segment) =>
    sum + segment.heartRate * (segment.endTime - segment.startTime), 0) / last.seconds
  const splits: PerformanceSegment[] = []
  for (let startDistance = 0; startDistance < last.distance - 1e-9; startDistance += 1) {
    const endDistance = Math.min(startDistance + 1, last.distance)
    let duration = 0
    let heartRateTotal = 0
    let startTime = 0
    for (const segment of segments) {
      const from = Math.max(startDistance, segment.startDistance)
      const to = Math.min(endDistance, segment.endDistance)
      if (to <= from) continue
      const elapsed = (to - from) * 3600 / segment.speed
      if (duration === 0) startTime = segment.startTime + (from - segment.startDistance) * 3600 / segment.speed
      duration += elapsed
      heartRateTotal += segment.heartRate * elapsed
    }
    splits.push({
      startDistance, endDistance, startTime, endTime: startTime + duration,
      speed: (endDistance - startDistance) * 3600 / duration,
      heartRate: heartRateTotal / duration,
    })
  }
  return {
    segments, splits, distance: last.distance, duration: last.seconds,
    averageSpeed: last.distance * 3600 / last.seconds,
    averageHeartRate,
  }
}
