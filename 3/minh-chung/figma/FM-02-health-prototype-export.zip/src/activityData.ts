import type { IconName } from './ui'
export const initialActivities = [
  { name: 'Chạy bộ buổi sáng', type: 'Chạy bộ', icon: 'run' as IconName, date: 'Hôm nay, 24 Tháng 5', isoDate: '2025-05-24', time: '06:15', distance: '5,24', duration: '32:18', calories: 328, color: 'green' },
  { name: 'Đạp xe quanh Hồ Tây', type: 'Đạp xe', icon: 'bike' as IconName, date: 'Hôm qua, 23 Tháng 5', isoDate: '2025-05-23', time: '17:30', distance: '15,80', duration: '58:42', calories: 486, color: 'blue' },
  { name: 'Dạo bước chiều mát', type: 'Đi bộ', icon: 'walk' as IconName, date: '22 Tháng 5, 2025', isoDate: '2025-05-22', time: '17:45', distance: '3,20', duration: '42:10', calories: 165, color: 'orange' },
  { name: 'Bơi lội cuối ngày', type: 'Bơi lội', icon: 'swim' as IconName, date: '21 Tháng 5, 2025', isoDate: '2025-05-21', time: '18:00', distance: '1,50', duration: '45:00', calories: 360, color: 'purple' },
]
export type Activity = typeof initialActivities[number]
