export const scheduleWeekdays = ["T2", "T3", "T4", "T5", "T6", "T7", "CN"]

export type Schedule = {
  id: string
  name: string
  type: string
  time: string
  daily: boolean
  days: string[]
  reminder: boolean
  minutes: number
  goal: number
  unit: "km" | "phút" | "km/h"
  date?: string
  once?: boolean
}

export function vietnamToday(now = new Date()) {
  const parts = new Intl.DateTimeFormat("en-CA", {
    timeZone: "Asia/Ho_Chi_Minh",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  }).formatToParts(now)
  return ["year", "month", "day"]
    .map((type) => parts.find((part) => part.type === type)!.value)
    .join("-")
}

// Calendar arithmetic uses UTC date-only values, independent of the device timezone.
export const calendarDate = (value: string) => new Date(`${value}T00:00:00Z`)
export const dateKey = (value: Date) => value.toISOString().slice(0, 10)
export const weekdayFor = (value: string) =>
  scheduleWeekdays[(calendarDate(value).getUTCDay() + 6) % 7]

export function scheduleOccursOn(schedule: Schedule, date: string) {
  if (schedule.once) return schedule.date === date
  if (schedule.date && date < schedule.date) return false
  return schedule.daily || schedule.days.includes(weekdayFor(date))
}

export function schedulesOnDate(schedules: Schedule[], date: string) {
  return schedules
    .filter((schedule) => scheduleOccursOn(schedule, date))
    .sort(
      (a, b) =>
        a.time.localeCompare(b.time) || a.name.localeCompare(b.name, "vi"),
    )
}

export function calendarDays(month: string) {
  const start = calendarDate(`${month}-01`)
  start.setUTCDate(start.getUTCDate() - ((start.getUTCDay() + 6) % 7))
  return Array.from({ length: 42 }, (_, index) => {
    const date = new Date(start)
    date.setUTCDate(date.getUTCDate() + index)
    return dateKey(date)
  })
}

export function shiftMonth(month: string, offset: number) {
  const date = calendarDate(`${month}-01`)
  date.setUTCMonth(date.getUTCMonth() + offset)
  return dateKey(date).slice(0, 7)
}

export function scheduleDateLabel(date: string) {
  return calendarDate(date).toLocaleDateString("vi-VN", {
    weekday: "long",
    day: "2-digit",
    month: "2-digit",
    year: "numeric",
    timeZone: "UTC",
  })
}
