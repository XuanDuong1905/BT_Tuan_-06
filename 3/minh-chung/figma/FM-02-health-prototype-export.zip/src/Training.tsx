import { useEffect, useRef, useState, type ReactNode } from "react"
import { Icon, type IconName } from "./ui"
import {
  formatShareNumber as number,
  shareTotals,
  workoutsInPeriod,
  type PeriodKind,
  type ShareWorkout,
} from "./workoutSharing"
import ScheduleCalendar from "./ScheduleCalendar"
import {
  ShareButton as Button,
  ShareHeading as Heading,
  ShareInput as Input,
} from "./ShareControls"
import {
  scheduleWeekdays as days,
  vietnamToday,
  weekdayFor,
  scheduleDateLabel,
  type Schedule,
} from "./scheduleCalendar"

const types = ["Đi bộ", "Chạy bộ", "Đạp xe", "Bơi lội", "Khác"]
export type { Schedule } from "./scheduleCalendar"
export type Goal = { id: string; name: string; activityType: string; metric: 'distance' | 'duration' | 'speed'; target: number; period: PeriodKind; date: string }
export const initialSchedules: Schedule[] = [
  { id: 'morning', name: 'Chạy bộ buổi sáng', type: 'Chạy bộ', time: '06:00', daily: false, days: ['T2', 'T4', 'T6'], reminder: true, minutes: 15, goal: 5, unit: 'km' },
  { id: 'weekend', name: 'Đạp xe cuối tuần', type: 'Đạp xe', time: '07:00', daily: false, days: ['T7', 'CN'], reminder: true, minutes: 30, goal: 20, unit: 'km' },
]
export const initialGoals: Goal[] = [
  { id: 'weekly', name: 'Vận động 40 km mỗi tuần', activityType: 'Tất cả', metric: 'distance', target: 40, period: 'week', date: '2025-05-24' },
  { id: 'schedule-morning', name: 'Chạy bộ buổi sáng', activityType: 'Chạy bộ', metric: 'distance', target: 5, period: 'week', date: '2025-05-24' },
  { id: 'schedule-weekend', name: 'Đạp xe cuối tuần', activityType: 'Đạp xe', metric: 'distance', target: 20, period: 'week', date: '2025-05-24' },
]
function EditorDialog({
  title,
  onClose,
  children,
}: {
  title: string
  onClose: () => void
  children: ReactNode
}) {
  const ref = useRef<HTMLElement>(null)
  useEffect(() => {
    const previous = document.activeElement as HTMLElement | null
    ;(
      ref.current?.querySelector<HTMLInputElement>("input") ??
      ref.current?.querySelector<HTMLButtonElement>("button")
    )?.focus()
    return () => previous?.focus()
  }, [])
  return (
    <div className="modal-backdrop" onClick={onClose}>
      <section
        ref={ref}
        role="dialog"
        aria-modal="true"
        aria-label={title}
        className="schedule-modal"
        onClick={(event) => event.stopPropagation()}
        onKeyDown={(event) => {
          if (event.key === "Escape") onClose()
          if (event.key === "Tab") {
            const items = [
              ...(ref.current?.querySelectorAll<HTMLElement>(
                "button:not(:disabled), input:not(:disabled), select:not(:disabled)",
              ) ?? []),
            ]
            if (event.shiftKey && document.activeElement === items[0]) {
              event.preventDefault()
              items[items.length - 1]?.focus()
            }
            if (
              !event.shiftKey &&
              document.activeElement === items[items.length - 1]
            ) {
              event.preventDefault()
              items[0]?.focus()
            }
          }
        }}
      >
        <div className="modal-heading">
          <h2>{title}</h2>
          <button className="icon-button" aria-label="Đóng" onClick={onClose}>
            <Icon name="close" />
          </button>
        </div>
        {children}
      </section>
    </div>
  )
}
function ScheduleForm({
  initial,
  initialDate,
  onClose,
  onSave,
}: {
  initial?: Schedule
  initialDate?: string
  onClose: () => void
  onSave: (schedule: Schedule) => void
}) {
  const [draft, setDraft] = useState<Schedule>(
    initial ?? {
      id: `schedule-${Date.now()}`,
      name: "",
      type: "Chạy bộ",
      time: "06:00",
      daily: !initialDate,
      days: [weekdayFor(initialDate ?? vietnamToday())],
      reminder: true,
      minutes: 15,
      goal: 5,
      unit: "km",
      date: initialDate ?? vietnamToday(),
      once: !!initialDate,
    },
  )
  const change = <K extends keyof Schedule>(key: K, value: Schedule[K]) =>
    setDraft((current) => ({ ...current, [key]: value }))
  const invalidDays = !draft.once && !draft.daily && draft.days.length === 0
  return (
    <EditorDialog
      title={initial ? "Chỉnh sửa lịch tập" : "Thêm lịch tập mới"}
      onClose={onClose}
    >
      <form
        onSubmit={(event) => {
          event.preventDefault()
          if (!invalidDays) onSave(draft)
        }}
      >
        <label>
          Tên hoạt động
          <input
            required
            value={draft.name}
            onChange={(event) => change("name", event.target.value)}
            placeholder="Ví dụ: Chạy bộ buổi sáng"
          />
        </label>
        <div className="form-row">
          <label>
            Loại hoạt động
            <select
              value={draft.type}
              onChange={(event) => change("type", event.target.value)}
            >
              {types.map((type) => (
                <option key={type}>{type}</option>
              ))}
            </select>
          </label>
          <label>
            Giờ bắt đầu
            <input
              type="time"
              required
              value={draft.time}
              onChange={(event) => change("time", event.target.value)}
            />
          </label>
        </div>
        <label>
          Tần suất
          <select
            value={draft.once ? "once" : draft.daily ? "daily" : "days"}
            onChange={(event) =>
              setDraft((current) => ({
                ...current,
                daily: event.target.value === "daily",
                once: event.target.value === "once",
                date:
                  event.target.value === "once"
                    ? current.date || vietnamToday()
                    : current.date,
              }))
            }
          >
            <option value="daily">Hàng ngày</option>
            <option value="days">Chọn ngày</option>
            <option value="once">Không lặp lại</option>
          </select>
        </label>
        <label>
          {draft.once ? "Ngày tập" : "Ngày bắt đầu (không bắt buộc)"}
          <Input
            type="date"
            required={draft.once}
            value={draft.date ?? ""}
            onChange={(event) =>
              change("date", event.target.value || undefined)
            }
          />
        </label>
        {!draft.once && !draft.daily && (
          <fieldset className="training-days">
            <legend>Ngày trong tuần</legend>
            {days.map((day) => (
              <label key={day}>
                <input
                  type="checkbox"
                  checked={draft.days.includes(day)}
                  onChange={() =>
                    change(
                      "days",
                      draft.days.includes(day)
                        ? draft.days.filter((item) => item !== day)
                        : days.filter(
                            (item) => item === day || draft.days.includes(item),
                          ),
                    )
                  }
                />
                {day}
              </label>
            ))}
          </fieldset>
        )}
        {invalidDays && (
          <p className="field-error">Chọn ít nhất một ngày trong tuần.</p>
        )}
        <div className="form-row">
          <label className="checkbox-label">
            <input
              type="checkbox"
              checked={draft.reminder}
              onChange={(event) => change("reminder", event.target.checked)}
            />
            Bật nhắc nhở
          </label>
          <label>
            Nhắc trước (phút)
            <input
              type="number"
              min="0"
              max="1440"
              required
              disabled={!draft.reminder}
              value={draft.minutes}
              onChange={(event) =>
                change("minutes", Number(event.target.value))
              }
            />
          </label>
        </div>
        <div className="form-row">
          <label>
            Mục tiêu
            <input
              required
              type="number"
              min=".1"
              step=".1"
              value={draft.goal}
              onChange={(event) => change("goal", Number(event.target.value))}
            />
          </label>
          <label>
            Đơn vị
            <select
              value={draft.unit}
              onChange={(event) =>
                change("unit", event.target.value as Schedule["unit"])
              }
            >
              <option value="km">Quãng đường (km)</option>
              <option value="phút">Thời gian (phút)</option>
              <option value="km/h">Tốc độ trung bình (km/h)</option>
            </select>
          </label>
        </div>
        <p className="panel-footnote">
          Mục tiêu được theo dõi trong tab Mục tiêu. Nhắc nhở trong bản trải
          nghiệm chỉ là mô phỏng.
        </p>
        {initial && !initial.once && (
          <p className="panel-footnote">
            Chỉnh sửa sẽ áp dụng cho toàn bộ lịch lặp và cập nhật các ngày tương
            ứng trên lịch tháng.
          </p>
        )}
        <button className="primary-button" disabled={invalidDays} type="submit">
          Lưu lịch tập
        </button>
      </form>
    </EditorDialog>
  )
}
export function Schedules({
  schedules,
  onChange,
  onSave,
}: {
  schedules: Schedule[]
  onChange: (schedules: Schedule[]) => void
  onSave: (schedule: Schedule) => void
}) {
  const [editing, setEditing] = useState<Schedule | "new" | null>(null)
  const [creationDate, setCreationDate] = useState<string>()
  const [deleting, setDeleting] = useState<Schedule | null>(null)
  return (
    <div className="training-screen schedule-screen">
      <div className="section-bar">
        <div>
          <h2>Lịch tập của bạn</h2>
          <p>Lặp lại đều đặn, duy trì thói quen tốt.</p>
        </div>
        <button className="primary-button" onClick={() => setEditing("new")}>
          <Icon name="plus" size={16} />
          Thêm lịch
        </button>
      </div>
      <ScheduleCalendar
        schedules={schedules}
        onAdd={(date) => {
          setCreationDate(date)
          setEditing("new")
        }}
        onEdit={setEditing}
      />
      <div className="schedule-all-heading">
        <Heading>Tất cả lịch tập</Heading>
        <span className="schedule-count">{schedules.length} lịch</span>
      </div>
      <div className="schedule-items">
        {schedules.map((schedule) => (
          <article className="schedule-large" key={schedule.id}>
            <span className="activity-icon green">
              <Icon
                name={
                  ({
                    "Đạp xe": "bike",
                    "Bơi lội": "swim",
                    "Đi bộ": "walk",
                  } as Record<string, IconName>)[schedule.type] ?? "run"
                }
              />
            </span>
            <div className="schedule-copy">
              <h3>{schedule.name}</h3>
              <p>
                {schedule.once && schedule.date
                  ? `Không lặp lại · ${scheduleDateLabel(schedule.date)}`
                  : schedule.daily
                    ? "Hàng ngày"
                    : schedule.days.join(", ")}{" "}
                · {schedule.time}
              </p>
              {!schedule.once && schedule.date && (
                <p>Từ {scheduleDateLabel(schedule.date)}</p>
              )}
              <p>
                {schedule.reminder
                  ? `Nhắc trước ${schedule.minutes} phút`
                  : "Đã tắt nhắc nhở"}
              </p>
              <span className="goal-chip">
                Mục tiêu: {number(schedule.goal)} {schedule.unit}
              </span>
              <div className="schedule-list-actions">
                <button
                  className="text-button"
                  onClick={() => setEditing(schedule)}
                >
                  Chỉnh sửa lịch
                </button>
                <Button
                  className="text-button schedule-delete"
                  onClick={() => setDeleting(schedule)}
                >
                  Xóa lịch
                </Button>
              </div>
            </div>
            <button
              className={`toggle ${schedule.reminder ? "on" : ""}`}
              role="switch"
              aria-checked={schedule.reminder}
              aria-label={`Nhắc nhở ${schedule.name}`}
              onClick={() =>
                onChange(
                  schedules.map((item) =>
                    item.id === schedule.id
                      ? { ...item, reminder: !item.reminder }
                      : item,
                  ),
                )
              }
            >
              <span />
            </button>
          </article>
        ))}
      </div>
      <p className="panel-footnote">
        Tất cả thời gian là giờ Việt Nam. Nhắc nhở là mô phỏng trong bản trải
        nghiệm.
      </p>
      {editing && (
        <ScheduleForm
          initial={editing === "new" ? undefined : editing}
          initialDate={editing === "new" ? creationDate : undefined}
          onClose={() => {
            setEditing(null)
            setCreationDate(undefined)
          }}
          onSave={(schedule) => {
            onSave(schedule)
            setEditing(null)
            setCreationDate(undefined)
          }}
        />
      )}
      {deleting && (
        <EditorDialog title="Xóa lịch tập?" onClose={() => setDeleting(null)}>
          <p className="schedule-delete-description">
            Bạn muốn xóa <strong>{deleting.name}</strong>?{" "}
            {deleting.once
              ? "Buổi tập sẽ được gỡ khỏi lịch."
              : "Toàn bộ lịch lặp sẽ bị xóa, bao gồm mọi lần xuất hiện trên lịch tháng."}{" "}
            Mục tiêu đã tạo vẫn được giữ trong tab Mục tiêu.
          </p>
          <div className="schedule-delete-actions">
            <Button
              className="schedule-cancel-button"
              onClick={() => setDeleting(null)}
            >
              Hủy
            </Button>
            <Button
              className="schedule-delete-confirm"
              onClick={() => {
                onChange(
                  schedules.filter((schedule) => schedule.id !== deleting.id),
                )
                setDeleting(null)
              }}
            >
              Xóa lịch tập
            </Button>
          </div>
        </EditorDialog>
      )}
    </div>
  )
}
function GoalForm({ initial, onClose, onSave }: { initial?: Goal; onClose: () => void; onSave: (goal: Goal) => void }) {
  const [draft, setDraft] = useState<Goal>(initial ?? { id: `goal-${Date.now()}`, name: '', activityType: 'Tất cả', metric: 'distance', target: 40, period: 'week', date: '2025-05-24' })
  const change = <K extends keyof Goal>(key: K, value: Goal[K]) => setDraft(current => ({ ...current, [key]: value }))
  return <EditorDialog title={initial ? 'Chỉnh sửa mục tiêu' : 'Tạo mục tiêu'} onClose={onClose}><form onSubmit={event => { event.preventDefault(); onSave(draft) }}>
    <label>Tên mục tiêu<input required value={draft.name} onChange={event => change('name', event.target.value)} placeholder="Ví dụ: Chạy 40 km mỗi tuần" /></label>
    <label>Hoạt động áp dụng<select value={draft.activityType} onChange={event => change('activityType', event.target.value)}>{['Tất cả', ...types].map(type => <option key={type}>{type}</option>)}</select></label>
    <div className="form-row"><label>Loại mục tiêu<select value={draft.metric} onChange={event => change('metric', event.target.value as Goal['metric'])}><option value="distance">Quãng đường (km)</option><option value="duration">Thời gian (phút)</option><option value="speed">Tốc độ trung bình (km/h)</option></select></label><label>Giá trị cần đạt<input required type="number" min=".1" step=".1" value={draft.target} onChange={event => change('target', Number(event.target.value))} /></label></div>
    <div className="form-row"><label>Chu kỳ mục tiêu<select value={draft.period} onChange={event => { const period = event.target.value as PeriodKind; setDraft(current => ({ ...current, period, date: period === 'week' ? '2025-05-24' : period === 'month' ? '2025-05' : '2025' })) }}><option value="week">Tuần</option><option value="month">Tháng</option><option value="year">Năm</option></select></label><label>Giai đoạn theo dõi<input required type={draft.period === 'week' ? 'date' : draft.period === 'month' ? 'month' : 'number'} min={draft.period === 'year' ? 2000 : undefined} max={draft.period === 'year' ? 2100 : undefined} value={draft.date} onChange={event => change('date', event.target.value)} /></label></div>
    <button className="primary-button" type="submit">Lưu mục tiêu</button>
  </form></EditorDialog>
}
export default function Goals({ goals, workouts, onSave }: { goals: Goal[]; workouts: ShareWorkout[]; onSave: (goal: Goal) => void }) {
  const [editing, setEditing] = useState<Goal | 'new' | null>(null)
  return <div className="training-screen"><div className="section-bar"><div><h2>Mục tiêu của bạn</h2><p>Theo dõi tiến bộ, theo nhịp của riêng bạn.</p></div><button className="primary-button" onClick={() => setEditing('new')}><Icon name="plus" size={16} />Tạo mục tiêu</button></div>
    <div className="goal-items">{goals.map(goal => {
      const rows = workoutsInPeriod(workouts, goal.period, goal.date).filter(workout => goal.activityType === 'Tất cả' || workout.type === goal.activityType)
      const totals = shareTotals(rows)
      const value = goal.metric === 'distance' ? totals.distance : goal.metric === 'duration' ? totals.duration / 60 : totals.speed
      const ratio = Math.min(100, value / goal.target * 100)
      const unit = goal.metric === 'distance' ? 'km' : goal.metric === 'duration' ? 'phút' : 'km/h'
      return <article className="goal-card goal-item" key={goal.id}><div className="section-bar"><h3>{goal.name}</h3><Icon name="target" size={20} /></div><p>{goal.activityType} · {goal.period === 'week' ? 'Tuần' : goal.period === 'month' ? 'Tháng' : 'Năm'} · {goal.date}</p><div className="goal-numbers"><strong>{number(value, 2)} <small>/ {number(goal.target)} {unit}</small></strong><span>{number(ratio, 0)}%</span></div><progress value={ratio} max="100" aria-label={`Tiến độ ${goal.name}`} /><p>{ratio >= 100 ? 'Đã hoàn thành mục tiêu!' : `Còn ${number(Math.max(0, goal.target - value), 2)} ${unit} để đạt mục tiêu.`}</p><button className="text-button" onClick={() => setEditing(goal)}>Chỉnh sửa mục tiêu <Icon name="arrow" size={15} /></button></article>
    })}</div><p className="panel-footnote">Tiến độ tự cập nhật từ dữ liệu mẫu và các buổi tập đồng bộ. Mục tiêu tốc độ sử dụng tổng quãng đường chia tổng thời gian.</p>
    {editing && <GoalForm initial={editing === 'new' ? undefined : editing} onClose={() => setEditing(null)} onSave={goal => { onSave(goal); setEditing(null) }} />}
  </div>
}
