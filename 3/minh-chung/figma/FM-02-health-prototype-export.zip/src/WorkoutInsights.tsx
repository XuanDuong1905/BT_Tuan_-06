import { useId, useState } from 'react'

type Workout = { icon: string; duration: string; distance: string; calories: number }
type Sample = { seconds: number; distance: number; calories: number; elevation: number }

const formatNumber = (value: number, digits = 0) =>
  value.toLocaleString('vi-VN', { maximumFractionDigits: digits, minimumFractionDigits: digits })
const formatTime = (seconds: number) => {
  const rounded = Math.round(seconds)
  return `${Math.floor(rounded / 60).toString().padStart(2, '0')}:${(rounded % 60).toString().padStart(2, '0')}`
}

export function workoutSamples(workout: Workout): Sample[] {
  const [minutes, seconds] = workout.duration.split(':').map(Number)
  const duration = minutes * 60 + seconds
  const distance = Number(workout.distance.replace(',', '.'))
  const elevations: Record<string, number[]> = {
    run: [8, 10, 14, 12, 17, 20, 16, 19, 15, 18, 13, 10, 8],
    bike: [9, 12, 17, 14, 21, 26, 20, 24, 18, 23, 16, 12, 9],
    walk: [8, 9, 11, 10, 13, 15, 12, 14, 11, 13, 10, 9, 8],
    swim: Array(13).fill(5),
  }
  const distances = [0, .065, .143, .23, .31, .397, .48, .57, .656, .747, .835, .92, 1]
  const energy = [0, .055, .126, .207, .294, .386, .476, .57, .662, .755, .842, .925, 1]
  return (elevations[workout.icon] ?? elevations.run).map((elevation, i) => ({
    seconds: duration * i / 12,
    distance: distance * distances[i],
    calories: workout.calories * energy[i],
    elevation,
  }))
}

export function elevationStats(samples: Sample[]) {
  let gain = 0
  let loss = 0
  samples.slice(1).forEach((sample, i) => {
    const change = sample.elevation - samples[i].elevation
    gain += Math.max(0, change)
    loss += Math.max(0, -change)
  })
  return { gain, loss, min: Math.min(...samples.map(s => s.elevation)), max: Math.max(...samples.map(s => s.elevation)) }
}

function interpolate(samples: Sample[], fraction: number, axis: 'seconds' | 'distance'): Sample {
  const target = fraction * samples[samples.length - 1][axis]
  const end = samples.findIndex((s, i) => i > 0 && s[axis] >= target)
  if (end === -1) return samples[samples.length - 1]
  const a = samples[end - 1]
  const b = samples[end]
  const ratio = (target - a[axis]) / (b[axis] - a[axis])
  return {
    seconds: a.seconds + (b.seconds - a.seconds) * ratio,
    distance: a.distance + (b.distance - a.distance) * ratio,
    calories: a.calories + (b.calories - a.calories) * ratio,
    elevation: a.elevation + (b.elevation - a.elevation) * ratio,
  }
}

export function InsightSummary({ workout }: { workout: Workout }) {
  const stats = elevationStats(workoutSamples(workout))
  return <div className="insight-summaries">
    <div className="insight-summary calorie-summary"><span>Calo tiêu thụ</span><strong>{formatNumber(workout.calories)} <small>kcal</small></strong><p>Năng lượng tích lũy trong buổi tập</p></div>
    <div className="insight-summary elevation-summary"><span>Độ cao thay đổi</span><strong>+{stats.gain} <small>m</small></strong><p>Tăng {stats.gain} m · Giảm {stats.loss} m</p><p>Thấp nhất {stats.min} m · Cao nhất {stats.max} m</p></div>
  </div>
}

export default function WorkoutInsights({ workout, elevationOnly = false, chartOnly = false, metricOverride }: { workout: Workout; elevationOnly?: boolean; chartOnly?: boolean; metricOverride?: 'calories' | 'elevation' }) {
  const [storedTab, setTab] = useState(elevationOnly ? 'elevation' : 'calories')
  const tab = metricOverride ?? storedTab
  const [axis, setAxis] = useState<'seconds' | 'distance'>(elevationOnly ? 'distance' : 'seconds')
  const [timeFraction, setTimeFraction] = useState(.5)
  const id = useId()
  const samples = workoutSamples(workout)
  const totals = samples[samples.length - 1]
  const stats = elevationStats(samples)
  const calories = tab === 'calories'
  const horizontal = calories ? 'seconds' : axis
  const field = calories ? 'calories' : 'elevation'
  const selected = interpolate(samples, timeFraction, 'seconds')
  const lower = calories ? 0 : Math.max(0, stats.min - 2)
  const upper = calories ? Math.ceil(totals.calories / 100) * 100 : stats.max + 3
  const x = (sample: Sample) => 36 + sample[horizontal] / totals[horizontal] * 312
  const y = (sample: Sample) => 144 - (sample[field] - lower) / (upper - lower) * 122
  const path = samples.map((sample, i) => `${i === 0 ? 'M' : 'L'}${x(sample)},${y(sample)}`).join(' ')
  const selectAt = (fraction: number) => {
    const sample = interpolate(samples, Math.min(1, Math.max(0, fraction)), horizontal)
    setTimeFraction(sample.seconds / totals.seconds)
  }
  const pointLabel = `${formatTime(selected.seconds)} · ${formatNumber(selected.distance, 2)} km · ${formatNumber(selected[field], calories ? 0 : 1)} ${calories ? 'kcal' : 'm'}`

  return <section className="workout-insights" aria-label={elevationOnly ? 'Độ cao thay đổi trong quá trình di chuyển' : 'Calo tiêu thụ và độ cao'}>
    {!elevationOnly && !chartOnly && <InsightSummary workout={workout} />}
    {!elevationOnly && !chartOnly && <div className="insight-tabs" role="tablist" aria-label="Phân tích buổi tập">
      <button id={`${id}-calories-tab`} role="tab" aria-selected={calories} aria-controls={`${id}-panel`} className={calories ? 'active' : ''} onClick={() => setTab('calories')}>Calo tiêu thụ</button>
      <button id={`${id}-elevation-tab`} role="tab" aria-selected={!calories} aria-controls={`${id}-panel`} className={!calories ? 'active' : ''} onClick={() => setTab('elevation')}>Độ cao</button>
    </div>}
    <div id={`${id}-panel`} role={elevationOnly || chartOnly ? undefined : 'tabpanel'} aria-labelledby={elevationOnly || chartOnly ? undefined : `${id}-${tab}-tab`} className={`insight-panel ${calories ? 'calorie-panel' : 'elevation-panel'}`}>
      <div className="insight-panel-heading">
        <div><h3>{calories ? 'Calo tích lũy' : 'Độ cao'}</h3><p>{calories ? 'Năng lượng tiêu thụ từ lúc bắt đầu' : 'Độ cao so với mực nước biển'}</p></div>
        {!calories && <div className="segmented" aria-label="Trục ngang biểu đồ độ cao">
          <button aria-pressed={axis === 'seconds'} className={axis === 'seconds' ? 'selected' : ''} onClick={() => setAxis('seconds')}>Thời gian</button>
          <button aria-pressed={axis === 'distance'} className={axis === 'distance' ? 'selected' : ''} onClick={() => setAxis('distance')}>Quãng đường</button>
        </div>}
      </div>
      {!calories && !chartOnly && <div className="elevation-metrics">
        {[[`+${stats.gain} m`, 'Tổng độ cao tăng'], [`−${stats.loss} m`, 'Tổng độ cao giảm'], [`${stats.min} m`, 'Độ cao thấp nhất'], [`${stats.max} m`, 'Độ cao cao nhất']].map(([value, label]) => <div key={label}><strong>{value}</strong><span>{label}</span></div>)}
      </div>}
      <div className="inspection-readout" aria-live="polite" aria-atomic="true">
        <span>{formatTime(selected.seconds)} <small>đã trôi qua · {formatNumber(selected.distance, 2)} km</small></span>
        <strong>{formatNumber(selected[field], calories ? 0 : 1)} <small>{calories ? 'kcal' : 'm'}</small></strong>
      </div>
      <svg className="inspectable-chart" viewBox="0 0 360 180" role="slider" tabIndex={0}
        aria-label={calories ? 'Khám phá calo tích lũy theo thời gian' : 'Khám phá độ cao theo buổi tập'}
        aria-valuemin={0} aria-valuemax={Math.round(totals.seconds)} aria-valuenow={Math.round(selected.seconds)} aria-valuetext={pointLabel}
        onPointerDown={e => { e.currentTarget.setPointerCapture(e.pointerId); const rect = e.currentTarget.getBoundingClientRect(); selectAt(((e.clientX - rect.left) / rect.width * 360 - 36) / 312) }}
        onPointerMove={e => { if (!e.currentTarget.hasPointerCapture(e.pointerId) && e.pointerType !== 'mouse') return; const rect = e.currentTarget.getBoundingClientRect(); selectAt(((e.clientX - rect.left) / rect.width * 360 - 36) / 312) }}
        onPointerUp={e => { if (e.currentTarget.hasPointerCapture(e.pointerId)) e.currentTarget.releasePointerCapture(e.pointerId) }}
        onKeyDown={e => { if (!['ArrowLeft', 'ArrowRight', 'Home', 'End'].includes(e.key)) return; e.preventDefault(); setTimeFraction(current => e.key === 'Home' ? 0 : e.key === 'End' ? 1 : Math.min(1, Math.max(0, current + (e.key === 'ArrowRight' ? .01 : -.01)))) }}>
        <defs><linearGradient id={`${id}-fill`} x1="0" x2="0" y1="0" y2="1"><stop offset="0" stopColor="currentColor" stopOpacity=".2" /><stop offset="1" stopColor="currentColor" stopOpacity=".02" /></linearGradient></defs>
        {[0, .5, 1].map(f => <g key={f}><line x1="36" x2="348" y1={144 - f * 122} y2={144 - f * 122} className="insight-grid" /><text x="29" y={147 - f * 122} textAnchor="end" className="insight-axis">{formatNumber(lower + f * (upper - lower))}</text></g>)}
        <text x="36" y="11" className="insight-axis">{calories ? 'kcal' : 'm'}</text>
        <path d={`${path} L348,144 L36,144 Z`} fill={`url(#${id}-fill)`} />
        <path d={path} fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinejoin="round" />
        <line x1={x(selected)} x2={x(selected)} y1="19" y2="144" className="insight-crosshair" />
        <circle cx={x(selected)} cy={y(selected)} r="4.5" fill="currentColor" stroke="white" strokeWidth="2" />
        {[0, .25, .5, .75, 1].map(f => <text key={f} x={36 + f * 312} y="163" textAnchor={f === 0 ? 'start' : f === 1 ? 'end' : 'middle'} className="insight-axis">{horizontal === 'seconds' ? formatTime(totals.seconds * f) : formatNumber(totals.distance * f, 2)}</text>)}
      </svg>
      <div className="insight-chart-footer"><span>Chạm hoặc kéo để xem chi tiết</span><span>{horizontal === 'seconds' ? 'Thời gian (phút:giây)' : 'Quãng đường (km)'}</span></div>
      {workout.icon === 'swim' && !calories && <p className="flat-elevation-note">Bơi trong hồ: độ cao ổn định, không có độ cao tăng hoặc giảm.</p>}
    </div>
  </section>
}
