import { useCallback, useEffect, useState } from 'react'
import { Icon } from './ui'
import { initialActivities, type Activity } from './activityData'
import { elevationStats, workoutSamples } from './WorkoutInsights'
import RetainedPanel from './RetainedPanel'
import TabNavigation from './TabNavigation'
import ActivityDetails from './ActivityDetails'
import Statistics from './Statistics'
import Goals, { Schedules, initialGoals, initialSchedules, type Goal, type Schedule } from './Training'
import WatchModule from './WatchModule'
import ShareCustomizer from './ShareCustomizer'
import type { PeriodKind } from './workoutSharing'
import './workout-insights.css'
import './workout-performance.css'
import './tabs.css'

const mainTabs = [
  { key: 'activities', label: 'Hoạt động', icon: <Icon name="activity" /> },
  { key: 'statistics', label: 'Thống kê', icon: <Icon name="grid" /> },
  { key: 'schedules', label: 'Lịch tập', icon: <Icon name="calendar" /> },
  { key: 'goals', label: 'Mục tiêu', icon: <Icon name="target" /> },
]
type Sharing = { scope: 'workout' } | { scope: 'summary'; kind: PeriodKind; value: string }
function ActivityElevation({ activity }: { activity: Activity }) {
  const stats = elevationStats(workoutSamples(activity))
  return <span className="activity-elevation">Độ cao: tăng {stats.gain} m · giảm {stats.loss} m</span>
}
export default function App() {
  const [page, setPage] = useState('activities')
  const [module, setModule] = useState('phone')
  const [activities, setActivities] = useState(initialActivities)
  const [filter, setFilter] = useState('Tất cả')
  const [dates, setDates] = useState({ from: '', to: '' })
  const [detail, setDetail] = useState<Activity | null>(null)
  const [sharing, setSharing] = useState<Sharing | null>(null)
  const [schedules, setSchedules] = useState(initialSchedules)
  const [goals, setGoals] = useState(initialGoals)
  const [toast, setToast] = useState('')
  useEffect(() => { if (!toast) return; const timer = setTimeout(() => setToast(''), 4000); return () => clearTimeout(timer) }, [toast])
  const onSync = useCallback((activity: Activity) => {
    setActivities(current => [activity, ...current])
    setToast('Đã đồng bộ hoạt động mới. Xem trong tab Hoạt động.')
  }, [])
  const saveGoal = (goal: Goal) => {
    setGoals(current => current.some(item => item.id === goal.id) ? current.map(item => item.id === goal.id ? goal : item) : [...current, goal])
    setToast('Đã lưu mục tiêu. Tiến độ được tính từ các buổi tập phù hợp.')
  }
  const saveSchedule = (schedule: Schedule) => {
    setSchedules(current => current.some(item => item.id === schedule.id) ? current.map(item => item.id === schedule.id ? schedule : item) : [...current, schedule])
    const goal: Goal = { id: `schedule-${schedule.id}`, name: schedule.name, activityType: schedule.type, metric: schedule.unit === 'km' ? 'distance' : schedule.unit === 'phút' ? 'duration' : 'speed', target: schedule.goal, period: 'week', date: '2025-05-24' }
    setGoals(current => current.some(item => item.id === goal.id) ? current.map(item => item.id === goal.id ? goal : item) : [...current, goal])
    setToast('Đã lưu lịch tập và cập nhật mục tiêu tương ứng.')
  }
  const invalidDates = !!dates.from && !!dates.to && dates.from > dates.to
  const filtered = activities.filter(activity => (filter === 'Tất cả' || activity.type === filter) && (!dates.from || activity.isoDate >= dates.from) && (!dates.to || activity.isoDate <= dates.to))
    .sort((a, b) => `${b.isoDate} ${b.time}`.localeCompare(`${a.isoDate} ${a.time}`))
  const currentLabel = mainTabs.find(tab => tab.key === page)?.label ?? 'Hoạt động'
  const phoneActive = module === 'phone'
  return <div className="app-shell tabbed-app">
    <aside className="sidebar">
      <button className="brand" aria-label="Về Hoạt động" onClick={() => { setModule('phone'); setPage('activities') }}><span className="brand-mark"><Icon name="activity" size={26} /></span>nhịp<span className="brand-period">.</span></button>
      <div className="workspace-label">THEO NHỊP CỦA BẠN</div>
      <div className="sidebar-intro"><span className="stat-icon green"><Icon name="heart" /></span><strong>Khỏe hơn,<br />mỗi ngày.</strong><p>Mỗi chuyển động là một bước tiến. Bắt đầu từ nhịp của riêng bạn.</p></div>
      <div className="sidebar-bottom"><div className="connection"><span className="device-icon"><Icon name="watch" /></span><div><strong>Nhịp Watch S1</strong><span><i /> Kết nối mô phỏng</span></div><Icon name="bluetooth" size={16} /></div><div className="profile"><div className="avatar">MA</div><div><strong>Minh Anh</strong><span>Tài khoản mẫu</span></div></div></div>
    </aside>
    <div className="main-shell">
      <header className="topbar"><div className="breadcrumb">Không gian cá nhân <span>/</span><strong>{phoneActive ? currentLabel : 'Đồng hồ'}</strong></div><div className="topbar-right"><div className="segmented module-switch" aria-label="Chọn mô-đun"><button aria-pressed={phoneActive} className={phoneActive ? 'selected' : ''} onClick={() => setModule('phone')}>Điện thoại</button><button aria-pressed={!phoneActive} className={!phoneActive ? 'selected' : ''} onClick={() => setModule('watch')}>Đồng hồ</button></div><span className="sample-tag">Bản trải nghiệm</span><button className="icon-button notification" aria-label="Thông báo" onClick={() => setToast('Dữ liệu mẫu từ 21–24/05/2025. Tiếp tục giữ nhịp vận động nhé!')}><Icon name="bell" /><i /></button><div className="avatar small">MA</div></div></header>
      <main className="tabbed-main">
        <section className="page-heading"><div><div className="eyebrow">MỖI CHUYỂN ĐỘNG, MỘT BƯỚC TIẾN</div><h1>{phoneActive ? { activities: 'Hoạt động của bạn', statistics: 'Nhịp vận động của bạn', schedules: 'Sẵn sàng cho buổi tập mới', goals: 'Từng bước chạm mục tiêu' }[page] : 'Theo dõi ngay trên cổ tay'}</h1><p>{phoneActive ? 'Lịch sử, phân tích, kế hoạch — mỗi phần một không gian riêng.' : 'Ghi nhận hoạt động và đồng bộ với điện thoại qua Bluetooth.'}</p></div></section>
        <div className={`dashboard-grid module-${module}`}>
          <section className="phone-workspace" hidden={!phoneActive} aria-label="Ứng dụng điện thoại">
            <div className="phone-panels">
              <section className="main-tab-container" id="phone-panel-activities" role="tabpanel" aria-labelledby="phone-tab-activities" hidden={page !== 'activities'}>
                <RetainedPanel id="activity-history" active={phoneActive && page === 'activities' && !detail} className="history-panel">
                  <div className="section-bar"><div><h2>Lịch sử hoạt động <span className="count">{filtered.length}</span></h2><p>Nhấn vào một buổi tập để xem chi tiết.</p></div><span className="sample-tag">Dữ liệu mẫu</span></div>
                  <div className="activity-date-filters"><label>Từ ngày<input type="date" value={dates.from} max={dates.to || undefined} onChange={event => setDates(current => ({ ...current, from: event.target.value }))} /></label><label>Đến ngày<input type="date" value={dates.to} min={dates.from || undefined} onChange={event => setDates(current => ({ ...current, to: event.target.value }))} /></label><button className="text-button" onClick={() => { setDates({ from: '', to: '' }); setFilter('Tất cả') }}>Xóa bộ lọc</button></div>
                  {invalidDates && <p className="field-error">Ngày bắt đầu phải trước hoặc bằng ngày kết thúc.</p>}
                  <div className="filter-tabs" aria-label="Loại hoạt động">{['Tất cả', 'Chạy bộ', 'Đi bộ', 'Đạp xe', 'Bơi lội'].map(type => <button key={type} className={filter === type ? 'active' : ''} aria-pressed={filter === type} onClick={() => setFilter(type)}>{type}</button>)}</div>
                  <div className="activity-list">{filtered.map((activity, index) => <button className="activity-row" key={`${activity.name}-${activity.isoDate}-${index}`} onClick={() => setDetail(activity)}><span className={`activity-icon ${activity.color}`}><Icon name={activity.icon} size={24} /></span><span className="activity-info"><strong>{activity.name}</strong><span>{activity.date}<i />{activity.time}</span><span className="activity-calories">Calo tiêu thụ: {activity.calories.toLocaleString('vi-VN')} kcal</span><ActivityElevation activity={activity} /></span><span className="activity-distance"><strong>{activity.distance} <small>km</small></strong><span>{activity.duration}</span></span><span className="row-chevron"><Icon name="chevron" size={16} /></span></button>)}</div>
                  {!filtered.length && <div className="empty-state">Không có hoạt động phù hợp. Hãy đổi ngày hoặc loại hoạt động.</div>}
                  <p className="panel-footnote">Dữ liệu minh họa từ 21–24/05/2025 · Không phải dữ liệu cá nhân.</p>
                </RetainedPanel>
                {detail && <ActivityDetails key={`${detail.name}-${detail.isoDate}-${detail.time}`} workout={detail} active={phoneActive && page === 'activities'} onBack={() => setDetail(null)} onShare={() => setSharing({ scope: 'workout' })} />}
              </section>
              <RetainedPanel active={phoneActive && page === 'statistics'} id="phone-panel-statistics" labelledBy="phone-tab-statistics"><Statistics workouts={activities} onShare={(kind, value) => setSharing({ scope: 'summary', kind, value })} /></RetainedPanel>
              <RetainedPanel active={phoneActive && page === 'schedules'} id="phone-panel-schedules" labelledBy="phone-tab-schedules"><Schedules schedules={schedules} onChange={setSchedules} onSave={saveSchedule} /></RetainedPanel>
              <RetainedPanel active={phoneActive && page === 'goals'} id="phone-panel-goals" labelledBy="phone-tab-goals"><Goals goals={goals} workouts={activities} onSave={saveGoal} /></RetainedPanel>
            </div>
            <nav className="phone-bottom-nav" aria-label="Điều hướng chính"><TabNavigation options={mainTabs} value={page} onChange={setPage} prefix="phone" label="Các mục chính" className="main-tabs" /></nav>
          </section>
          <aside className="watch-module"><WatchModule onSync={onSync} /><p className="watch-module-note">Mô-đun đồng hồ · Chỉ theo dõi và đồng bộ hoạt động.</p></aside>
        </div>
      </main>
    </div>
    {sharing && <ShareCustomizer workouts={activities} workout={sharing.scope === 'workout' ? detail ?? undefined : undefined} initialPeriod={sharing.scope === 'summary' ? sharing.kind : 'week'} initialValue={sharing.scope === 'summary' ? sharing.value : undefined} onClose={() => setSharing(null)} />}
    {toast && <div className="toast" role="status"><Icon name="check" size={18} />{toast}</div>}
  </div>
}
